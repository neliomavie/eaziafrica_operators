<footer id="main-footer">

<div class="container">
<div id="footer-widgets" class="clearfix">
<div class="footer-widget"><div id="text-4" class="fwidget et_pb_widget widget_text"><h4 class="title">Contact</h4>			<div class="textwidget"><p>South Africa: <a href="tel:+27861003294">+27 86 100 3294</a><br />
Mozambique: <a href="tel:+258872115809">+258 87 211 5809</a><br />
Namibia: <a href="tel:+2648193294">+264 81 9 3294</a><br />
Zambia: <a href="tel:+27794900775">+27 79 490 0775</a><br />
Zimbabwe: <a href="tel:+263787228781">+263 78 722 8781</a><br />
Email: <a href="mailto:info@eazi.co.za">info@eazi.co.za</a></p>
</div>
</div> <!-- end .fwidget --></div> <!-- end .footer-widget --><div class="footer-widget"><div id="text-2" class="fwidget et_pb_widget widget_text"><h4 class="title">Address</h4>			<div class="textwidget"><p>Allandale Offices<br />
23 Magwa Crescent<br />
Waterfall City<br />
2090</p>
</div>
</div> <!-- end .fwidget --></div> <!-- end .footer-widget --><div class="footer-widget"><div id="text-3" class="fwidget et_pb_widget widget_text"><h4 class="title">Legal</h4>			<div class="textwidget"><p><a href="/terms-of-service/">Terms of Service</a><br />
<a href="/disclaimer/">Disclaimer</a><br />
<a href="/wp-content/uploads/2020/04/Eazi_Access_Rental_-_Final_Certificate_and_Detailed_Scorecard-2020.pdf" target="_blank" rel="noopener noreferrer">BBBEE</a><br />
<a href="/wp-content/uploads/2020/05/EAR_Letter_of_Good_Standing_2020.pdf" target="_blank" rel="noopener noreferrer">Letter of Good Standing</a><br />
<a href="/wp-content/uploads/2020/05/EAR_Tax_Clearance_Pin_2020.pdf" target="_blank" rel="noopener noreferrer">Tax Clearance Pin</a></p>
</div>
</div> <!-- end .fwidget --></div> <!-- end .footer-widget --><div class="footer-widget"><div id="glt_widget-2" class="fwidget et_pb_widget widget_glt_widget"><h4 class="title">Language</h4><div id="flags" class="size24"><ul id="sortable" class="ui-sortable" style="float:left"><li id="English"><a href="#" title="English" class="nturl notranslate en flag English"></a></li><li id="French"><a href="#" title="French" class="nturl notranslate fr flag French"></a></li><li id="Portuguese"><a href="#" title="Portuguese" class="nturl notranslate pt flag Portuguese"></a></li><li id="German"><a href="#" title="German" class="nturl notranslate de flag German"></a></li></ul></div><div id="google_language_translator" class="default-language-en"></div></div> <!-- end .fwidget --></div> <!-- end .footer-widget -->    </div> <!-- #footer-widgets -->
</div>    <!-- .container -->


<div id="footer-bottom">
<div class="container clearfix">
<div id="footer-info">Eazi Access © 2018 — All Rights Reserved.</div>					</div>	<!-- .container -->
</div>
</footer> <!-- #main-footer -->