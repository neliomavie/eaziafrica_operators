<!DOCTYPE html>
<html lang="en-GB">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="pingback" href="https://www.eazi.co.za/xmlrpc.php" />

    <script type="text/javascript">
    document.documentElement.className = 'js';
    </script>

    <script>
    var et_site_url = 'https://www.eazi.co.za';
    var et_post_id = '1909';

    function et_core_page_resource_fallback(a, b) {
        "undefined" === typeof b && (b = a.sheet.cssRules && 0 === a.sheet.cssRules.length);
        b && (a.onerror = null, a.onload = null, a.href ? a.href = et_site_url + "/?et_core_page_resource=" + a.id +
            et_post_id : a.src && (a.src = et_site_url + "/?et_core_page_resource=" + a.id + et_post_id))
    }
    </script>
    <!-- This site is optimized with the Yoast SEO plugin v14.4 - https://yoast.com/wordpress/plugins/seo/ -->
    <title>Rent | Eazi Access</title>
    <meta name="robots" content="index, follow" />
    <meta name="googlebot" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
    <meta name="bingbot" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
    <link rel="canonical" href="https://www.eazi.co.za/rent/" />
    <meta property="og:locale" content="en_GB" />
    <meta property="og:type" content="article" />
    <meta property="og:title" content="Rent | Eazi Access" />
    <meta property="og:url" content="https://www.eazi.co.za/rent/" />
    <meta property="og:site_name" content="Eazi Access" />
    <meta property="article:modified_time" content="2019-08-23T13:27:41+00:00" />
    <meta name="twitter:card" content="summary_large_image" />
    <script type="application/ld+json" class="yoast-schema-graph">
    {
        "@context": "https://schema.org",
        "@graph": [{
            "@type": "Organization",
            "@id": "https://www.eazi.co.za/#organization",
            "name": "Eazi Access",
            "url": "https://www.eazi.co.za/",
            "sameAs": [],
            "logo": {
                "@type": "ImageObject",
                "@id": "https://www.eazi.co.za/#logo",
                "inLanguage": "en-GB",
                "url": "https://www.eazi.co.za/wp-content/uploads/2019/06/eazi-logo-b-1.png",
                "width": 300,
                "height": 43,
                "caption": "Eazi Access"
            },
            "image": {
                "@id": "https://www.eazi.co.za/#logo"
            }
        }, {
            "@type": "WebSite",
            "@id": "https://www.eazi.co.za/#website",
            "url": "https://www.eazi.co.za/",
            "name": "Eazi Access",
            "description": "Work-at-height and material-handling solutions.",
            "publisher": {
                "@id": "https://www.eazi.co.za/#organization"
            },
            "potentialAction": [{
                "@type": "SearchAction",
                "target": "https://www.eazi.co.za/?s={search_term_string}",
                "query-input": "required name=search_term_string"
            }],
            "inLanguage": "en-GB"
        }, {
            "@type": "WebPage",
            "@id": "https://www.eazi.co.za/rent/#webpage",
            "url": "https://www.eazi.co.za/rent/",
            "name": "Rent | Eazi Access",
            "isPartOf": {
                "@id": "https://www.eazi.co.za/#website"
            },
            "datePublished": "2018-09-24T06:18:06+00:00",
            "dateModified": "2019-08-23T13:27:41+00:00",
            "inLanguage": "en-GB",
            "potentialAction": [{
                "@type": "ReadAction",
                "target": ["https://www.eazi.co.za/rent/"]
            }]
        }]
    }
    </script>
    <!-- / Yoast SEO plugin. -->


    <link rel='dns-prefetch' href='//translate.google.com' />
    <link rel='dns-prefetch' href='//www.google.com' />
    <link rel='dns-prefetch' href='//fonts.googleapis.com' />
    <link rel='dns-prefetch' href='//s.w.org' />
    <link rel="alternate" type="application/rss+xml" title="Eazi Access &raquo; Feed"
        href="https://www.eazi.co.za/feed/" />
    <script type="text/javascript">
    window._wpemojiSettings = {
        "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/",
        "ext": ".png",
        "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/",
        "svgExt": ".svg",
        "source": {
            "concatemoji": "https:\/\/www.eazi.co.za\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.1"
        }
    };
    ! function(e, a, t) {
        var r, n, o, i, p = a.createElement("canvas"),
            s = p.getContext && p.getContext("2d");

        function c(e, t) {
            var a = String.fromCharCode;
            s.clearRect(0, 0, p.width, p.height), s.fillText(a.apply(this, e), 0, 0);
            var r = p.toDataURL();
            return s.clearRect(0, 0, p.width, p.height), s.fillText(a.apply(this, t), 0, 0), r === p.toDataURL()
        }

        function l(e) {
            if (!s || !s.fillText) return !1;
            switch (s.textBaseline = "top", s.font = "600 32px Arial", e) {
                case "flag":
                    return !c([127987, 65039, 8205, 9895, 65039], [127987, 65039, 8203, 9895, 65039]) && (!c([55356,
                        56826, 55356, 56819
                    ], [55356, 56826, 8203, 55356, 56819]) && !c([55356, 57332, 56128, 56423, 56128, 56418,
                        56128, 56421, 56128, 56430, 56128, 56423, 56128, 56447
                    ], [55356, 57332, 8203, 56128, 56423, 8203, 56128, 56418, 8203, 56128, 56421, 8203,
                        56128, 56430, 8203, 56128, 56423, 8203, 56128, 56447
                    ]));
                case "emoji":
                    return !c([55357, 56424, 8205, 55356, 57212], [55357, 56424, 8203, 55356, 57212])
            }
            return !1
        }

        function d(e) {
            var t = a.createElement("script");
            t.src = e, t.defer = t.type = "text/javascript", a.getElementsByTagName("head")[0].appendChild(t)
        }
        for (i = Array("flag", "emoji"), t.supports = {
                everything: !0,
                everythingExceptFlag: !0
            }, o = 0; o < i.length; o++) t.supports[i[o]] = l(i[o]), t.supports.everything = t.supports.everything && t
            .supports[i[o]], "flag" !== i[o] && (t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && t
                .supports[i[o]]);
        t.supports.everythingExceptFlag = t.supports.everythingExceptFlag && !t.supports.flag, t.DOMReady = !1, t
            .readyCallback = function() {
                t.DOMReady = !0
            }, t.supports.everything || (n = function() {
                t.readyCallback()
            }, a.addEventListener ? (a.addEventListener("DOMContentLoaded", n, !1), e.addEventListener("load", n, !
                1)) : (e.attachEvent("onload", n), a.attachEvent("onreadystatechange", function() {
                "complete" === a.readyState && t.readyCallback()
            })), (r = t.source || {}).concatemoji ? d(r.concatemoji) : r.wpemoji && r.twemoji && (d(r.twemoji), d(r
                .wpemoji)))
    }(window, document, window._wpemojiSettings);
    </script>
    <meta content="Eazi v.3.4.1.1527599835" name="generator" />
    <style type="text/css">
    img.wp-smiley,
    img.emoji {
        display: inline !important;
        border: none !important;
        box-shadow: none !important;
        height: 1em !important;
        width: 1em !important;
        margin: 0 .07em !important;
        vertical-align: -0.1em !important;
        background: none !important;
        padding: 0 !important;
    }
    </style>
    <link rel='stylesheet' id='wp-notification-bars-css'
        href='https://www.eazi.co.za/wp-content/plugins/wp-notification-bars/public/css/wp-notification-bars-public.css?ver=1.0.5'
        type='text/css' media='all' />
    <link rel='stylesheet' id='wp-block-library-css'
        href='https://www.eazi.co.za/wp-includes/css/dist/block-library/style.min.css?ver=5.5.1' type='text/css'
        media='all' />
    <link rel='stylesheet' id='google-language-translator-css'
        href='https://www.eazi.co.za/wp-content/plugins/google-language-translator/css/style.css?ver=6.0.6'
        type='text/css' media='' />
    <link rel='stylesheet' id='chld_thm_cfg_parent-css'
        href='https://www.eazi.co.za/wp-content/themes/Divi/style.css?ver=5.5.1' type='text/css' media='all' />
    <link rel='stylesheet' id='divi-style-css'
        href='https://www.eazi.co.za/wp-content/themes/Divi-Eazi/style.css?ver=3.19.15' type='text/css' media='all' />
    <link rel='stylesheet' id='divi-enhancer-styles-css'
        href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/styles/style.min.css?ver=1.0.0'
        type='text/css' media='all' />
    <link rel='stylesheet' id='et-builder-googlefonts-cached-css'
        href='https://fonts.googleapis.com/css?family=Titillium+Web%3A200%2C200italic%2C300%2C300italic%2Cregular%2Citalic%2C600%2C600italic%2C700%2C700italic%2C900&#038;ver=5.5.1#038;subset=latin,latin-ext'
        type='text/css' media='all' />
    <link rel='stylesheet' id='gforms_reset_css-css'
        href='https://www.eazi.co.za/wp-content/plugins/gravityforms/css/formreset.min.css?ver=2.3.1' type='text/css'
        media='all' />
    <link rel='stylesheet' id='gforms_datepicker_css-css'
        href='https://www.eazi.co.za/wp-content/plugins/gravityforms/css/datepicker.min.css?ver=2.3.1' type='text/css'
        media='all' />
    <link rel='stylesheet' id='gforms_formsmain_css-css'
        href='https://www.eazi.co.za/wp-content/plugins/gravityforms/css/formsmain.min.css?ver=2.3.1' type='text/css'
        media='all' />
    <link rel='stylesheet' id='gforms_ready_class_css-css'
        href='https://www.eazi.co.za/wp-content/plugins/gravityforms/css/readyclass.min.css?ver=2.3.1' type='text/css'
        media='all' />
    <link rel='stylesheet' id='gforms_browsers_css-css'
        href='https://www.eazi.co.za/wp-content/plugins/gravityforms/css/browsers.min.css?ver=2.3.1' type='text/css'
        media='all' />
    <link rel='stylesheet' id='gform_chained_selects-css'
        href='https://www.eazi.co.za/wp-content/plugins/gravityformschainedselects/css/frontend.css?ver=1.0-beta-1'
        type='text/css' media='all' />
    <link rel='stylesheet' id='msl-main-css'
        href='https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/css/masterslider.main.css?ver=3.5.8'
        type='text/css' media='all' />
    <link rel='stylesheet' id='msl-custom-css'
        href='https://www.eazi.co.za/wp-content/uploads/master-slider/custom.css?ver=7' type='text/css' media='all' />
    <link rel='stylesheet' id='dashicons-css' href='https://www.eazi.co.za/wp-includes/css/dashicons.min.css?ver=5.5.1'
        type='text/css' media='all' />
    <link rel='stylesheet' id='divienhancer-slick-css-css'
        href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/styles/slick.css?ver=5.5.1'
        type='text/css' media='all' />
    <link rel='stylesheet' id='divienhancer-slick-theme-css'
        href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/styles/slick-theme.css?ver=5.5.1'
        type='text/css' media='all' />
    <link rel='stylesheet' id='divienhancer-twenty-css'
        href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/includes/modules/imageComparison/twentytwenty.css?ver=5.5.1'
        type='text/css' media='all' />
    <link rel='stylesheet' id='divienhancer-hovereffects-css'
        href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/styles/hover-effects.css?ver=5.5.1'
        type='text/css' media='all' />
    <link rel='stylesheet' id='divienhancer-nifty-css'
        href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/styles/nifty.css?ver=5.5.1'
        type='text/css' media='all' />
    <link rel='stylesheet' id='divienhancer-custom-css'
        href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/styles/custom.css?ver=5.5.1'
        type='text/css' media='all' />
    <link rel='stylesheet' id='main-css'
        href='https://www.eazi.co.za/wp-content/themes/Divi-Eazi/css/main.css?ver=201907151119' type='text/css'
        media='all' />
    <link rel='stylesheet' id='extra-css'
        href='https://www.eazi.co.za/wp-content/themes/Divi-Eazi/css/extra.css?ver=201911251504' type='text/css'
        media='all' />
    <script type='text/javascript' src='https://www.eazi.co.za/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'
        id='jquery-core-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/wp-notification-bars/public/js/wp-notification-bars-public.js?ver=1.0.5'
        id='wp-notification-bars-js'></script>
    <script type='text/javascript' id='divienhancer-additional-js-js-extra'>
    /* <![CDATA[ */
    var divienhancerData = {
        "url": "https:\/\/www.eazi.co.za\/wp-content\/plugins\/",
        "bingKey": ""
    };
    /* ]]> */
    </script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/main-scripts.js?ver=5.5.1'
        id='divienhancer-additional-js-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/gravityforms/js/jquery.json.min.js?ver=2.3.1' id='gform_json-js'>
    </script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/gravityforms/js/gravityforms.min.js?ver=2.3.1'
        id='gform_gravityforms-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/gravityforms/js/conditional_logic.min.js?ver=2.3.1'
        id='gform_conditional_logic-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/gravityforms/js/jquery.maskedinput.min.js?ver=2.3.1'
        id='gform_masked_input-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/gravityforms/js/placeholders.jquery.min.js?ver=2.3.1'
        id='gform_placeholder-js'></script>
    <script type='text/javascript' id='gform_chained_selects-js-extra'>
    /* <![CDATA[ */
    var gformChainedSelectData = {
        "ajaxUrl": "https:\/\/www.eazi.co.za\/wp-admin\/admin-ajax.php",
        "nonce": "37fc08f535",
        "spinner": "https:\/\/www.eazi.co.za\/wp-content\/plugins\/gravityforms\/images\/spinner.gif",
        "strings": {
            "loading": "Loading",
            "noOptions": "No options"
        }
    };
    /* ]]> */
    </script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/gravityformschainedselects/js/frontend.min.js?ver=1.0-beta-1'
        id='gform_chained_selects-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/modernizr.custom.js?ver=5.5.1'
        id='divienhancer-modernizr-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/slick.min.js?ver=5.5.1'
        id='divienhancer-slick-js-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/jquery.twentytwenty.js?ver=5.5.1'
        id='divienhancer-twentytwenty-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/jquery.sticky.js?ver=5.5.1'
        id='divienhancer-sticky-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/nifty.js?ver=5.5.1'
        id='divienhancer-nifty-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/jquery.interactive_bg.min.js?ver=5.5.1'
        id='divienhancer-interactive_bg-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/jquery.flip.min.js?ver=5.5.1'
        id='divienhancer-flipbox-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/jquery.event.move.js?ver=5.5.1'
        id='divienhancer-event-move-js'></script>
    <script>
    document.addEventListener("DOMContentLoaded", function(event) {
        window.et_location_hash = window.location.hash;
        if ("" !== window.et_location_hash) {
            // Prevent jump to anchor - Firefox
            window.scrollTo(0, 0);
            var et_anchor_element = document.getElementById(window.et_location_hash.substring(1));
            if (et_anchor_element === null) {
                return;
            }
            window.et_location_hash_style = et_anchor_element.style.display;
            // Prevent jump to anchor - Other Browsers
            et_anchor_element.style.display = "none";
        }
    });
    </script>
    <link rel="https://api.w.org/" href="https://www.eazi.co.za/wp-json/" />
    <link rel="alternate" type="application/json" href="https://www.eazi.co.za/wp-json/wp/v2/pages/1909" />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.eazi.co.za/xmlrpc.php?rsd" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml"
        href="https://www.eazi.co.za/wp-includes/wlwmanifest.xml" />
    <meta name="generator" content="WordPress 5.5.1" />
    <link rel='shortlink' href='https://www.eazi.co.za/?p=1909' />
    <link rel="alternate" type="application/json+oembed"
        href="https://www.eazi.co.za/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.eazi.co.za%2Frent%2F" />
    <link rel="alternate" type="text/xml+oembed"
        href="https://www.eazi.co.za/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.eazi.co.za%2Frent%2F&#038;format=xml" />
    <style type="text/css">
    p.hello {
        font-size: 12px;
        color: darkgray;
    }

    #google_language_translator,
    #flags {
        text-align: left;
    }

    #google_language_translator {
        clear: both;
    }

    #flags {
        width: 165px;
    }

    #flags a {
        display: inline-block;
        margin-right: 2px;
    }

    #google_language_translator a {
        display: none !important;
    }

    .goog-te-gadget {
        color: transparent !important;
    }

    .goog-te-gadget {
        font-size: 0px !important;
    }

    .goog-branding {
        display: none;
    }

    .goog-tooltip {
        display: none !important;
    }

    .goog-tooltip:hover {
        display: none !important;
    }

    .goog-text-highlight {
        background-color: transparent !important;
        border: none !important;
        box-shadow: none !important;
    }

    #google_language_translator {
        display: none;
    }

    #google_language_translator select.goog-te-combo {
        color: #000000;
    }

    .goog-te-banner-frame {
        visibility: hidden !important;
    }

    body {
        top: 0px !important;
    }

    #glt-translate-trigger {
        left: 20px;
        right: auto;
    }

    #glt-translate-trigger>span {
        color: #ffffff;
    }

    #glt-translate-trigger {
        background: #f89406;
    }

    .goog-te-gadget .goog-te-combo {
        width: 100%;
    }

    #google_language_translator .goog-te-gadget .goog-te-combo {
        background: #ffc72c;
        border: 0 !important;
    }
    </style>
    <script>
    var ms_grabbing_curosr =
        'https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/css/common/grabbing.cur',
        ms_grab_curosr = 'https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/css/common/grab.cur';
    </script>
    <meta name="generator" content="MasterSlider 3.5.8 - Responsive Touch Image Slider | avt.li/msf" />
    <script>
    jQuery(window).on('load', function() {
        jQuery('body').removeClass('et-loading');
    });
    </script>
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />


    <style type="text/css">
    #main-header .nav li ul a {
        font-size: px;
    }



    @media only screen and (max-width: 980px) {
        #logo {
            max-height: px;
            >
        }
    }
    </style>


    <style type="text/css" id="custom-background-css">
    body.custom-background {
        background-color: #ffc72c;
    }
    </style>
    <!-- Google Tag Manager -->

    <script>
    (function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-TLRR726');
    </script>

    <!-- End Google Tag Manager -->

    <!-- Fontawesome for icons use -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css"
        integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
    <!-- Open and close form modals -->
    <script type="text/javascript">
    jQuery(function($) {
        jQuery('.button_quote').click(function() {
            jQuery('#form_quote').css('display', 'block');
        });
        // 		jQuery('.close_quote').click(function() {
        // 			jQuery('#form_quote').css('display', 'none');
        // 			location.hash = "cta_quote";
        // 		});
    });
    </script>
    <link rel="icon" href="https://www.eazi.co.za/wp-content/uploads/2018/11/cropped-favicon-32x32.png" sizes="32x32" />
    <link rel="icon" href="https://www.eazi.co.za/wp-content/uploads/2018/11/cropped-favicon-192x192.png"
        sizes="192x192" />
    <link rel="apple-touch-icon" href="https://www.eazi.co.za/wp-content/uploads/2018/11/cropped-favicon-180x180.png" />
    <meta name="msapplication-TileImage"
        content="https://www.eazi.co.za/wp-content/uploads/2018/11/cropped-favicon-270x270.png" />
    <link rel="stylesheet" id="et-core-unified-cached-inline-styles"
        href="https://www.eazi.co.za/wp-content/cache/et/1909/et-core-unified-16000113147665.min.css"
        onerror="et_core_page_resource_fallback(this, true)" onload="et_core_page_resource_fallback(this)" />
    <style id="kirki-inline-styles"></style>
</head>


<body
    class="page-template-default page page-id-1909 custom-background _masterslider _ms_version_3.5.8 divienhancer-free et-loading et_button_custom_icon et_pb_button_helper_class et_fullwidth_nav et_fullwidth_secondary_nav et_fixed_nav et_show_nav et_cover_background et_pb_gutter windows et_pb_gutters3 et_primary_nav_dropdown_animation_fade et_secondary_nav_dropdown_animation_slide et_pb_footer_columns4 et_header_style_left et_pb_pagebuilder_layout et_smooth_scroll et_right_sidebar et_divi_theme et-db et_minified_js et_minified_css">
    <div id="page-container">

        @include('auth.header')

        @include('auth.form')

        @include('auth.footer')


    </div> <!-- #page-container -->


    <script>
    jQuery(document).ready(function() {

        if (jQuery('.button_quote').length > 0) {

            jQuery('.button_quote').off('click');
            jQuery('.button_quote').on('click', function(e) {

                var product_title = jQuery(e.currentTarget).data('product');

                console.log('button_quote click: ', e.currentTarget);
                console.log('product_title: ', product_title);

                jQuery('#form_quote').css('display', 'block');

                if (typeof product_title != 'undefined' && product_title != '') {
                    jQuery('#input_1_6').val('I know what equipment I need…').trigger('change');
                    jQuery('#input_1_7').val(product_title);
                }

            });

        }

    });
    </script>
    <script>
    function gf_datepicker_limit_past() {


        /**
         * Gravity Form Hooks
         */
        // Disable Past Dates.
        gform.addFilter('gform_datepicker_options_pre_init', function(optionsObj, formId, fieldId) {
            // Apply to field 2 only 
            if (formId == 1 && (fieldId == 9 || fieldId == 10)) {
                optionsObj.minDate = 0;
            }
            return optionsObj;
        });



    }
    </script>
    <script type="text/javascript">
    var et_animation_data = [{
        "class": "et_pb_text_0",
        "style": "slideBottom",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_text_1",
        "style": "fade",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_text_2",
        "style": "slideTop",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "17%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_button_0",
        "style": "zoom",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "500ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_text_3",
        "style": "fade",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_text_9",
        "style": "fade",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_section_8",
        "style": "zoomBottom",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "10%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_button_1",
        "style": "flipRight",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "20%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_text_21",
        "style": "fade",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_text_22",
        "style": "fade",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }, {
        "class": "et_pb_text_23",
        "style": "fade",
        "repeat": "once",
        "duration": "1000ms",
        "delay": "0ms",
        "intensity": "50%",
        "starting_opacity": "0%",
        "speed_curve": "ease-in-out"
    }];
    </script>
    <!-- Google Tag Manager (noscript) -->

    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TLRR726" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- Global Site Tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-35197551-1"></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments)
    };
    gtag('js', new Date());

    gtag('config', 'UA-35197551-1');
    </script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/google-language-translator/js/scripts.js?ver=6.0.6'
        id='scripts-js'></script>
    <script type='text/javascript' src='//translate.google.com/translate_a/element.js?cb=GoogleLanguageTranslatorInit'
        id='scripts-google-js'></script>
    <script type='text/javascript' id='google-invisible-recaptcha-js-before'>
    var renderInvisibleReCaptcha = function() {

        for (var i = 0; i < document.forms.length; ++i) {
            var form = document.forms[i];
            var holder = form.querySelector('.inv-recaptcha-holder');

            if (null === holder) continue;
            holder.innerHTML = '';

            (function(frm) {
                var cf7SubmitElm = frm.querySelector('.wpcf7-submit');
                var holderId = grecaptcha.render(holder, {
                    'sitekey': '6LeFeH0UAAAAADwKEI8eb_j4fHDi1nAZUNr8BNOa',
                    'size': 'invisible',
                    'badge': 'bottomright',
                    'callback': function(recaptchaToken) {
                        if ((null !== cf7SubmitElm) && (typeof jQuery != 'undefined')) {
                            jQuery(frm).submit();
                            grecaptcha.reset(holderId);
                            return;
                        }
                        HTMLFormElement.prototype.submit.call(frm);
                    },
                    'expired-callback': function() {
                        grecaptcha.reset(holderId);
                    }
                });

                if (null !== cf7SubmitElm && (typeof jQuery != 'undefined')) {
                    jQuery(cf7SubmitElm).off('click').on('click', function(clickEvt) {
                        clickEvt.preventDefault();
                        grecaptcha.execute(holderId);
                    });
                } else {
                    frm.onsubmit = function(evt) {
                        evt.preventDefault();
                        grecaptcha.execute(holderId);
                    };
                }


            })(form);
        }
    };
    </script>
    <script type='text/javascript' async defer
        src='https://www.google.com/recaptcha/api.js?onload=renderInvisibleReCaptcha&#038;render=explicit'
        id='google-invisible-recaptcha-js'></script>
    <script type='text/javascript' id='divi-custom-script-js-extra'>
    /* <![CDATA[ */
    var DIVI = {
        "item_count": "%d Item",
        "items_count": "%d Items"
    };
    var et_shortcodes_strings = {
        "previous": "Previous",
        "next": "Next"
    };
    var et_pb_custom = {
        "ajaxurl": "https:\/\/www.eazi.co.za\/wp-admin\/admin-ajax.php",
        "images_uri": "https:\/\/www.eazi.co.za\/wp-content\/themes\/Divi\/images",
        "builder_images_uri": "https:\/\/www.eazi.co.za\/wp-content\/themes\/Divi\/includes\/builder\/images",
        "et_frontend_nonce": "80b69d47a9",
        "subscription_failed": "Please, check the fields below to make sure you entered the correct information.",
        "et_ab_log_nonce": "ace18afdca",
        "fill_message": "Please, fill in the following fields:",
        "contact_error_message": "Please, fix the following errors:",
        "invalid": "Invalid email",
        "captcha": "Captcha",
        "prev": "Prev",
        "previous": "Previous",
        "next": "Next",
        "wrong_captcha": "You entered the wrong number in captcha.",
        "ignore_waypoints": "no",
        "is_divi_theme_used": "1",
        "widget_search_selector": ".widget_search",
        "is_ab_testing_active": "",
        "page_id": "1909",
        "unique_test_id": "",
        "ab_bounce_rate": "5",
        "is_cache_plugin_active": "yes",
        "is_shortcode_tracking": "",
        "tinymce_uri": ""
    };
    var et_pb_box_shadow_elements = [];
    /* ]]> */
    </script>
    <script type='text/javascript' src='https://www.eazi.co.za/wp-content/themes/Divi/js/custom.min.js?ver=3.19.15'
        id='divi-custom-script-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/frontend-bundle.min.js?ver=1.0.0'
        id='divi-enhancer-frontend-bundle-js'></script>
    <script type='text/javascript' src='https://www.eazi.co.za/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'
        id='jquery-ui-core-js'></script>
    <script type='text/javascript' src='https://www.eazi.co.za/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'
        id='jquery-ui-datepicker-js'></script>
    <script type='text/javascript' id='jquery-ui-datepicker-js-after'>
    jQuery(document).ready(function(jQuery) {
        jQuery.datepicker.setDefaults({
            "closeText": "Close",
            "currentText": "Today",
            "monthNames": ["January", "February", "March", "April", "May", "June", "July", "August",
                "September", "October", "November", "December"
            ],
            "monthNamesShort": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct",
                "Nov", "Dec"
            ],
            "nextText": "Next",
            "prevText": "Previous",
            "dayNames": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            "dayNamesShort": ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            "dayNamesMin": ["S", "M", "T", "W", "T", "F", "S"],
            "dateFormat": "dd\/mm\/yy",
            "firstDay": 1,
            "isRTL": false
        });
    });
    </script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/gravityforms/js/datepicker.min.js?ver=2.3.1'
        id='gform_datepicker_init-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/js/jquery.easing.min.js?ver=3.5.8'
        id='jquery-easing-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/js/masterslider.min.js?ver=3.5.8'
        id='masterslider-core-js'></script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/themes/Divi/core/admin/js/common.js?ver=3.19.15' id='et-core-common-js'>
    </script>
    <script type='text/javascript'
        src='https://www.eazi.co.za/wp-content/themes/Divi-Eazi/js/custom.js?ver=201908271856' id='custom-child-js-js'>
    </script>
    <script type='text/javascript' src='https://www.eazi.co.za/wp-includes/js/wp-embed.min.js?ver=5.5.1'
        id='wp-embed-js'></script>
</body>

</html>

<!-- Performance optimized by Redis Object Cache. Learn more: https://wprediscache.com -->