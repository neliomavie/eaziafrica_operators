<header id="main-header" data-height-onload="60">
<div class="container clearfix et_menu_container">
<div class="logo_container">
<span class="logo_helper"></span>
<a href="https://www.eazi.co.za/">
<img src="https://www.eazi.co.za/wp-content/uploads/2018/06/eazi-logo.png" alt="Eazi Access" id="logo" data-height-percentage="40" />
</a>
</div>
<div id="et-top-navigation" data-height="60" data-fixed-height="40">
<nav id="top-menu-nav">
<ul id="top-menu" class="nav"><li id="menu-item-1911" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-1909 current_page_item menu-item-1911"><a href="https://www.eazi.co.za/rent/" aria-current="page">Rent</a></li>
<li id="menu-item-2118" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-2118"><a href="#">Buy</a>
<ul class="sub-menu">
<li id="menu-item-1908" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1908"><a href="https://www.eazi.co.za/buy-new/">Buy New</a></li>
<li id="menu-item-2119" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2119"><a href="https://www.eazi.co.za/buy-used/">Buy Used</a></li>
</ul>
</li>
<li id="menu-item-404" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-404"><a href="#">Industry</a>
<ul class="sub-menu">
<li id="menu-item-1442" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1442"><a href="https://www.eazi.co.za/industry-construction/">Construction</a></li>
<li id="menu-item-1441" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1441"><a href="https://www.eazi.co.za/industry-entertainment/">Entertainment</a></li>
<li id="menu-item-1439" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1439"><a href="https://www.eazi.co.za/industry-heavy-industrial/">Heavy Industrial</a></li>
<li id="menu-item-1438" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1438"><a href="https://www.eazi.co.za/industry-light-industrial/">Light Industrial</a></li>
<li id="menu-item-1440" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1440"><a href="https://www.eazi.co.za/industry-mining/">Mining</a></li>
</ul>
</li>
<li id="menu-item-289" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-289"><a href="#">Service &#038; Parts</a>
<ul class="sub-menu">
<li id="menu-item-1490" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1490"><a href="https://www.eazi.co.za/service/">Service</a></li>
<li id="menu-item-1489" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1489"><a href="https://www.eazi.co.za/parts/">Parts</a></li>
</ul>
</li>
<li id="menu-item-1520" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1520"><a href="https://www.eazi.co.za/training/">Training</a></li>
<li id="menu-item-291" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-291"><a href="#">About</a>
<ul class="sub-menu">
<li id="menu-item-1587" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1587"><a href="https://www.eazi.co.za/about-us/">About Us</a></li>
<li id="menu-item-1586" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1586"><a href="https://www.eazi.co.za/our-team/">Our Team</a></li>
<li id="menu-item-2460" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2460"><a href="https://www.eazi.co.za/careers/">Careers</a></li>
<li id="menu-item-2489" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2489"><a href="https://www.eazi.co.za/news/">News</a></li>
</ul>
</li>
<li id="menu-item-2261" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2261"><a href="https://www.eazi.co.za/contact/">Contact</a></li>
</ul>						</nav>



<div id="et_top_search">
<span id="et_search_icon"></span>
</div>

<div id="et_mobile_nav_menu">
<div class="mobile_nav closed">
<span class="select_page">Select Page</span>
<span class="mobile_menu_bar mobile_menu_bar_toggle"></span>
</div>
</div>				</div> <!-- #et-top-navigation -->
</div> <!-- .container -->
<div class="et_search_outer">
<div class="container et_search_form_container">
<form role="search" method="get" class="et-search-form" action="https://www.eazi.co.za/">
    <input type="search" class="et-search-field" placeholder="Search &hellip;" value="" name="s" title="Search for:" />					</form>
    <span class="et_close_search_field"></span>
    </div>
    </div>
    </header> <!-- #main-header -->