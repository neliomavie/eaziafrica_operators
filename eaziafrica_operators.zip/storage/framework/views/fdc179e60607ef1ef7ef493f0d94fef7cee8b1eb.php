
<!DOCTYPE html>
<html lang="en-GB">
<head>
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="pingback" href="https://www.eazi.co.za/xmlrpc.php" />

<script type="text/javascript">
document.documentElement.className = 'js';
</script>

<script>var et_site_url='https://www.eazi.co.za';var et_post_id='37';function et_core_page_resource_fallback(a,b){"undefined"===typeof b&&(b=a.sheet.cssRules&&0===a.sheet.cssRules.length);b&&(a.onerror=null,a.onload=null,a.href?a.href=et_site_url+"/?et_core_page_resource="+a.id+et_post_id:a.src&&(a.src=et_site_url+"/?et_core_page_resource="+a.id+et_post_id))}
</script>
<!-- This site is optimized with the Yoast SEO plugin v14.4 - https://yoast.com/wordpress/plugins/seo/ -->
<title>Work-at-height and material-handling solutions | Eazi Access</title>
<meta name="robots" content="index, follow" />
<meta name="googlebot" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
<meta name="bingbot" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
<link rel="canonical" href="https://www.eazi.co.za/" />
<meta property="og:locale" content="en_GB" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Work-at-height and material-handling solutions | Eazi Access" />
<meta property="og:url" content="https://www.eazi.co.za/" />
<meta property="og:site_name" content="Eazi Access" />
<meta property="article:modified_time" content="2019-09-12T14:43:49+00:00" />
<meta property="og:image" content="https://www.eazi.co.za/wp-content/uploads/2018/09/jlg.svg" />
<meta name="twitter:card" content="summary_large_image" />
<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://www.eazi.co.za/#organization","name":"Eazi Access","url":"https://www.eazi.co.za/","sameAs":[],"logo":{"@type":"ImageObject","@id":"https://www.eazi.co.za/#logo","inLanguage":"en-GB","url":"https://www.eazi.co.za/wp-content/uploads/2019/06/eazi-logo-b-1.png","width":300,"height":43,"caption":"Eazi Access"},"image":{"@id":"https://www.eazi.co.za/#logo"}},{"@type":"WebSite","@id":"https://www.eazi.co.za/#website","url":"https://www.eazi.co.za/","name":"Eazi Access","description":"Work-at-height and material-handling solutions.","publisher":{"@id":"https://www.eazi.co.za/#organization"},"potentialAction":[{"@type":"SearchAction","target":"https://www.eazi.co.za/?s={search_term_string}","query-input":"required name=search_term_string"}],"inLanguage":"en-GB"},{"@type":"ImageObject","@id":"https://www.eazi.co.za/#primaryimage","inLanguage":"en-GB","url":"/wp-content/uploads/2018/09/jlg.svg"},{"@type":"WebPage","@id":"https://www.eazi.co.za/#webpage","url":"https://www.eazi.co.za/","name":"Work-at-height and material-handling solutions | Eazi Access","isPartOf":{"@id":"https://www.eazi.co.za/#website"},"about":{"@id":"https://www.eazi.co.za/#organization"},"primaryImageOfPage":{"@id":"https://www.eazi.co.za/#primaryimage"},"datePublished":"2018-05-30T11:50:10+00:00","dateModified":"2019-09-12T14:43:49+00:00","inLanguage":"en-GB","potentialAction":[{"@type":"ReadAction","target":["https://www.eazi.co.za/"]}]}]}</script>
  <!-- / Yoast SEO plugin. -->
  
  
  <link rel='dns-prefetch' href='//translate.google.com' />
  <link rel='dns-prefetch' href='//www.google.com' />
  <link rel='dns-prefetch' href='//fonts.googleapis.com' />
  <link rel='dns-prefetch' href='//s.w.org' />
  <link rel="alternate" type="application/rss+xml" title="Eazi Access &raquo; Feed" href="https://www.eazi.co.za/feed/" />
  <script type="text/javascript">
  window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.eazi.co.za\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.1"}};
  !function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
  </script>
  <meta content="Eazi v.3.4.1.1527599835" name="generator"/><style type="text/css">
  img.wp-smiley,
  img.emoji {
    display: inline !important;
    border: none !important;
    box-shadow: none !important;
    height: 1em !important;
    width: 1em !important;
    margin: 0 .07em !important;
    vertical-align: -0.1em !important;
    background: none !important;
    padding: 0 !important;
  }
  </style>
  <link rel='stylesheet' id='wp-notification-bars-css'  href='https://www.eazi.co.za/wp-content/plugins/wp-notification-bars/public/css/wp-notification-bars-public.css?ver=1.0.5' type='text/css' media='all' />
    <link rel='stylesheet' id='wp-block-library-css'  href='https://www.eazi.co.za/wp-includes/css/dist/block-library/style.min.css?ver=5.5.1' type='text/css' media='all' />
    <link rel='stylesheet' id='google-language-translator-css'  href='https://www.eazi.co.za/wp-content/plugins/google-language-translator/css/style.css?ver=6.0.6' type='text/css' media='' />
    <link rel='stylesheet' id='chld_thm_cfg_parent-css'  href='https://www.eazi.co.za/wp-content/themes/Divi/style.css?ver=5.5.1' type='text/css' media='all' />
    <link rel='stylesheet' id='divi-style-css'  href='https://www.eazi.co.za/wp-content/themes/Divi-Eazi/style.css?ver=3.19.15' type='text/css' media='all' />
    <link rel='stylesheet' id='divi-enhancer-styles-css'  href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/styles/style.min.css?ver=1.0.0' type='text/css' media='all' />
    <link rel='stylesheet' id='et-builder-googlefonts-cached-css'  href='https://fonts.googleapis.com/css?family=Titillium+Web%3A200%2C200italic%2C300%2C300italic%2Cregular%2Citalic%2C600%2C600italic%2C700%2C700italic%2C900&#038;ver=5.5.1#038;subset=latin,latin-ext' type='text/css' media='all' />
    <link rel='stylesheet' id='gforms_reset_css-css'  href='https://www.eazi.co.za/wp-content/plugins/gravityforms/css/formreset.min.css?ver=2.3.1' type='text/css' media='all' />
      <link rel='stylesheet' id='gforms_datepicker_css-css'  href='https://www.eazi.co.za/wp-content/plugins/gravityforms/css/datepicker.min.css?ver=2.3.1' type='text/css' media='all' />
        <link rel='stylesheet' id='gforms_formsmain_css-css'  href='https://www.eazi.co.za/wp-content/plugins/gravityforms/css/formsmain.min.css?ver=2.3.1' type='text/css' media='all' />
          <link rel='stylesheet' id='gforms_ready_class_css-css'  href='https://www.eazi.co.za/wp-content/plugins/gravityforms/css/readyclass.min.css?ver=2.3.1' type='text/css' media='all' />
            <link rel='stylesheet' id='gforms_browsers_css-css'  href='https://www.eazi.co.za/wp-content/plugins/gravityforms/css/browsers.min.css?ver=2.3.1' type='text/css' media='all' />
              <link rel='stylesheet' id='gform_chained_selects-css'  href='https://www.eazi.co.za/wp-content/plugins/gravityformschainedselects/css/frontend.css?ver=1.0-beta-1' type='text/css' media='all' />
                <link rel='stylesheet' id='msl-main-css'  href='https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/css/masterslider.main.css?ver=3.5.8' type='text/css' media='all' />
                <link rel='stylesheet' id='msl-custom-css'  href='https://www.eazi.co.za/wp-content/uploads/master-slider/custom.css?ver=7' type='text/css' media='all' />
                <link rel='stylesheet' id='dashicons-css'  href='https://www.eazi.co.za/wp-includes/css/dashicons.min.css?ver=5.5.1' type='text/css' media='all' />
                <link rel='stylesheet' id='divienhancer-slick-css-css'  href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/styles/slick.css?ver=5.5.1' type='text/css' media='all' />
                <link rel='stylesheet' id='divienhancer-slick-theme-css'  href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/styles/slick-theme.css?ver=5.5.1' type='text/css' media='all' />
                <link rel='stylesheet' id='divienhancer-twenty-css'  href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/includes/modules/imageComparison/twentytwenty.css?ver=5.5.1' type='text/css' media='all' />
                <link rel='stylesheet' id='divienhancer-hovereffects-css'  href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/styles/hover-effects.css?ver=5.5.1' type='text/css' media='all' />
                <link rel='stylesheet' id='divienhancer-nifty-css'  href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/styles/nifty.css?ver=5.5.1' type='text/css' media='all' />
                  <link rel='stylesheet' id='divienhancer-custom-css'  href='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/styles/custom.css?ver=5.5.1' type='text/css' media='all' />
                  <link rel='stylesheet' id='main-css'  href='https://www.eazi.co.za/wp-content/themes/Divi-Eazi/css/main.css?ver=201907151119' type='text/css' media='all' />
                  <link rel='stylesheet' id='extra-css'  href='https://www.eazi.co.za/wp-content/themes/Divi-Eazi/css/extra.css?ver=201911251504' type='text/css' media='all' />
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp' id='jquery-core-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/wp-notification-bars/public/js/wp-notification-bars-public.js?ver=1.0.5' id='wp-notification-bars-js'></script>
                  <script type='text/javascript' id='divienhancer-additional-js-js-extra'>
                  /* <![CDATA[ */
                  var divienhancerData = {"url":"https:\/\/www.eazi.co.za\/wp-content\/plugins\/","bingKey":""};
                  /* ]]> */
                  </script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/main-scripts.js?ver=5.5.1' id='divienhancer-additional-js-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/gravityforms/js/jquery.json.min.js?ver=2.3.1' id='gform_json-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/gravityforms/js/gravityforms.min.js?ver=2.3.1' id='gform_gravityforms-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/gravityforms/js/conditional_logic.min.js?ver=2.3.1' id='gform_conditional_logic-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/gravityforms/js/jquery.maskedinput.min.js?ver=2.3.1' id='gform_masked_input-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/gravityforms/js/placeholders.jquery.min.js?ver=2.3.1' id='gform_placeholder-js'></script>
                  <script type='text/javascript' id='gform_chained_selects-js-extra'>
                  /* <![CDATA[ */
                  var gformChainedSelectData = {"ajaxUrl":"https:\/\/www.eazi.co.za\/wp-admin\/admin-ajax.php","nonce":"37fc08f535","spinner":"https:\/\/www.eazi.co.za\/wp-content\/plugins\/gravityforms\/images\/spinner.gif","strings":{"loading":"Loading","noOptions":"No options"}};
                  /* ]]> */
                  </script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/gravityformschainedselects/js/frontend.min.js?ver=1.0-beta-1' id='gform_chained_selects-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/modernizr.custom.js?ver=5.5.1' id='divienhancer-modernizr-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/slick.min.js?ver=5.5.1' id='divienhancer-slick-js-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/jquery.twentytwenty.js?ver=5.5.1' id='divienhancer-twentytwenty-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/jquery.sticky.js?ver=5.5.1' id='divienhancer-sticky-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/nifty.js?ver=5.5.1' id='divienhancer-nifty-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/jquery.interactive_bg.min.js?ver=5.5.1' id='divienhancer-interactive_bg-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/jquery.flip.min.js?ver=5.5.1' id='divienhancer-flipbox-js'></script>
                  <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/jquery.event.move.js?ver=5.5.1' id='divienhancer-event-move-js'></script>
                  <script>
                  document.addEventListener( "DOMContentLoaded", function( event ) {
                    window.et_location_hash = window.location.hash;
                    if ( "" !== window.et_location_hash ) {
                      // Prevent jump to anchor - Firefox
                      window.scrollTo( 0, 0 );
                      var et_anchor_element = document.getElementById( window.et_location_hash.substring( 1 ) );
                      if( et_anchor_element === null ) {
                        return;
                      }
                      window.et_location_hash_style = et_anchor_element.style.display;
                      // Prevent jump to anchor - Other Browsers
                      et_anchor_element.style.display = "none";
                    }
                  } );
                  </script><link rel="https://api.w.org/" href="https://www.eazi.co.za/wp-json/" /><link rel="alternate" type="application/json" href="https://www.eazi.co.za/wp-json/wp/v2/pages/37" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.eazi.co.za/xmlrpc.php?rsd" />
                  <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.eazi.co.za/wp-includes/wlwmanifest.xml" /> 
                    <meta name="generator" content="WordPress 5.5.1" />
                    <link rel='shortlink' href='https://www.eazi.co.za/' />
                    <link rel="alternate" type="application/json+oembed" href="https://www.eazi.co.za/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.eazi.co.za%2F" />
                    <link rel="alternate" type="text/xml+oembed" href="https://www.eazi.co.za/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.eazi.co.za%2F&#038;format=xml" />
                    <style type="text/css">p.hello { font-size:12px; color:darkgray; }#google_language_translator, #flags { text-align:left; }#google_language_translator { clear:both; }#flags { width:165px; }#flags a { display:inline-block; margin-right:2px; }#google_language_translator a {display: none !important; }.goog-te-gadget {color:transparent !important;}.goog-te-gadget { font-size:0px !important; }.goog-branding { display:none; }.goog-tooltip {display: none !important;}.goog-tooltip:hover {display: none !important;}.goog-text-highlight {background-color: transparent !important; border: none !important; box-shadow: none !important;}#google_language_translator { display:none; }#google_language_translator select.goog-te-combo { color:#000000; }.goog-te-banner-frame{visibility:hidden !important;}body { top:0px !important;}#glt-translate-trigger { left:20px; right:auto; }#glt-translate-trigger > span { color:#ffffff; }#glt-translate-trigger { background:#f89406; }.goog-te-gadget .goog-te-combo { width:100%; }#google_language_translator .goog-te-gadget .goog-te-combo { background:#ffc72c; border:0 !important; }</style><script>var ms_grabbing_curosr = 'https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/css/common/grabbing.cur', ms_grab_curosr = 'https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/css/common/grab.cur';</script>
                    <meta name="generator" content="MasterSlider 3.5.8 - Responsive Touch Image Slider | avt.li/msf" />
                    <script>
                    
                    jQuery(window).on('load', function() {
                      jQuery('body').removeClass('et-loading');
                    });
                    
                    </script>
                    <meta name="format-detection" content="telephone=no"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
                    
                    
                    <style type="text/css">
                    
                    #main-header .nav li ul a {font-size:px;}
                    
                    
                    
                    @media  only screen and (max-width: 980px){
                      #logo {max-height: px;>}
                    }
                    
                    </style>
                    
                    
                    <style type="text/css" id="custom-background-css">
                    body.custom-background { background-color: #ffc72c; }
                    </style>
                    <!-- Google Tag Manager -->
                    
                    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
                      new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
                      j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
                      'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
                    })(window,document,'script','dataLayer','GTM-TLRR726');</script>
                    
                    <!-- End Google Tag Manager -->
                    
                    <!-- Fontawesome for icons use -->
                    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous"><!-- Open and close form modals -->
                    <script type="text/javascript">
                    jQuery(function($){
                      jQuery('.button_quote').click(function() {
                        jQuery('#form_quote').css('display', 'block');
                      });
                      // 		jQuery('.close_quote').click(function() {
                        // 			jQuery('#form_quote').css('display', 'none');
                        // 			location.hash = "cta_quote";
                        // 		});
                      });
                      </script><link rel="icon" href="https://www.eazi.co.za/wp-content/uploads/2018/11/cropped-favicon-32x32.png" sizes="32x32" />
                      <link rel="icon" href="https://www.eazi.co.za/wp-content/uploads/2018/11/cropped-favicon-192x192.png" sizes="192x192" />
                      <link rel="apple-touch-icon" href="https://www.eazi.co.za/wp-content/uploads/2018/11/cropped-favicon-180x180.png" />
                      <meta name="msapplication-TileImage" content="https://www.eazi.co.za/wp-content/uploads/2018/11/cropped-favicon-270x270.png" />
                      <link rel="stylesheet" id="et-core-unified-cached-inline-styles" href="https://www.eazi.co.za/wp-content/cache/et/37/et-core-unified-1600011374281.min.css" onerror="et_core_page_resource_fallback(this, true)" onload="et_core_page_resource_fallback(this)" /><style id="kirki-inline-styles"></style></head>
                        <body class="home page-template-default page page-id-37 custom-background _masterslider _ms_version_3.5.8 divienhancer-free et-loading et_button_custom_icon et_pb_button_helper_class et_fullwidth_nav et_fullwidth_secondary_nav et_fixed_nav et_show_nav et_cover_background et_pb_gutter windows et_pb_gutters3 et_primary_nav_dropdown_animation_fade et_secondary_nav_dropdown_animation_slide et_pb_footer_columns4 et_header_style_left et_pb_pagebuilder_layout et_smooth_scroll et_right_sidebar et_divi_theme et-db et_minified_js et_minified_css">
                        <div id="page-container">
                        
                        
                        
                        <header id="main-header" data-height-onload="60">
                        <div class="container clearfix et_menu_container">
                        <div class="logo_container">
                        <span class="logo_helper"></span>
                        <a href="https://www.eazi.co.za/">
                        <img src="https://www.eazi.co.za/wp-content/uploads/2018/06/eazi-logo.png" alt="Eazi Access" id="logo" data-height-percentage="40" />
                        </a>
                        </div>
                        <div id="et-top-navigation" data-height="60" data-fixed-height="40">
                        <nav id="top-menu-nav">
                        <ul id="top-menu" class="nav">
                        <li id="menu-item-1911" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1911">
                        <a href="https://www.eazi.co.za/rent/">Meu nome</a>
                        </li>
                        </li>
                        
                        
                        <li id="menu-item-289" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-289">
                        <a href="#"><font style="vertical-align: inherit;" class="">Registrar</font></a>
                        <ul class="sub-menu">
                        <li id="menu-item-1490" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1490">
                        <a href="https://www.eazi.co.za/service/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Operador</font></font></a></li>
                        <li id="menu-item-1489" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1489">
                        <a href="https://www.eazi.co.za/parts/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Site</font></font></a></li>
                        <li id="menu-item-1489" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1489">
                        <a href="https://www.eazi.co.za/parts/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Máquina</font></font></a></li>
                        <li id="menu-item-1489" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1489">
                        <a href="https://www.eazi.co.za/parts/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Usuário</font></font></a></li>
                        </ul>
                        </li>
                        
                        
                        
                        <li id="menu-item-2261" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2261">
                        <a href="https://www.eazi.co.za/contact/">Entrar</a> 
                        </li>
                        </ul>						
                        </nav>
                        
                        
                        
                        
                        
                        <div id="et_mobile_nav_menu">
                        <div class="mobile_nav closed">
                        <span class="select_page">Select Page</span>
                        <span class="mobile_menu_bar mobile_menu_bar_toggle"></span>
                        </div>
                        </div>				</div> <!-- #et-top-navigation -->
                        </div> <!-- .container -->
                        <div class="et_search_outer">
                        <div class="container et_search_form_container">
                        <form role="search" method="get" class="et-search-form" action="https://www.eazi.co.za/">
                          <input type="search" class="et-search-field" placeholder="Search &hellip;" value="" name="s" title="Search for:" />					</form>
                          <span class="et_close_search_field"></span>
                          </div>
                          </div>
                          </header> <!-- #main-header -->
                          <div id="et-main-area">
                          
                          <div id="main-content">
                          
                          
                          
                          <article id="post-37" class="post-37 page type-page status-publish hentry">
                          
                          
                          <div class="entry-content">
                          
                          <script type="text/javascript">
                          
                          ( function( $ ) {
                            
                            window.GWAdvCondLogic = function( args ) {
                              
                              var self = this;
                              
                              // copy all args to current object: (list expected props)
                              for( prop in args ) {
                                if( args.hasOwnProperty( prop ) )
                                self[prop] = args[prop];
                              }
                              
                              self.init = function() {
                                
                                self.doingLogic = false;
                                
                                // do the magic
                                
                                gform.addFilter( 'gform_is_value_match', function( isMatch, formId, rule ) {
                                  
                                  if( rule.value == '__return_true' ) {
                                    return true;
                                  } else if( rule.value != '__adv_cond_logic' || self.doingLogic ) {
                                    return isMatch;
                                  }
                                  
                                  self.doingLogic = true;
                                  
                                  isMatch = self.isAdvancedConditionalLogicMatch( formId, self.logic[ rule.fieldId ] );
                                  
                                  self.doingLogic = false;
                                  
                                  return isMatch;
                                } );
                                
                              };
                              
                              self.isAdvancedConditionalLogicMatch = function( formId, logic ) {
                                
                                for( var i in logic.groups ) {
                                  if( logic.groups.hasOwnProperty( i ) ) {
                                    var action = gf_get_field_action( formId, logic.groups[ i ] );
                                    if( action == 'show' ) {
                                      return true;
                                    }
                                  }
                                }
                                
                                return false;
                              };
                              
                              self.init();
                              
                            }
                            
                          } )( jQuery );
                          
                          </script>
                          
                          <div id="et-boc" class="et-boc">
                          
                          <div class="et_builder_inner_content et_pb_gutters3">
                          <div class="et_pb_section et_pb_section_0 et_pb_with_background et_section_regular">
                          
                          
                          
                          
                          <div class="et_pb_row et_pb_row_0 et_pb_equal_columns et_pb_gutters1 et_pb_row_fullwidth">
                          <div class="et_pb_column et_pb_column_1_2 et_pb_column_0  ds-vertical-align  et_pb_css_mix_blend_mode_passthrough">
                          
                          
                          <div class="et_pb_module  et_pb_text et_pb_text_0 et_animated et_pb_bg_layout_light  et_pb_text_align_left">
                          
                          
                          <div class="et_pb_text_inner">
                          <h5>Sistema de gestao de operadores</h5>
                          </div>
                          </div> <!-- .et_pb_text --><div class="et_pb_module  et_pb_text et_pb_text_1 et_animated et_pb_bg_layout_light  et_pb_text_align_left">
                          
                          
                          <div class="et_pb_text_inner">
                          <h1>Eazi Equip Africa</h1>
                          </div>
                          </div> <!-- .et_pb_text --><div class="et_pb_module  et_pb_text et_pb_text_2 et_animated et_pb_bg_layout_light  et_pb_text_align_left">
                          
                          
                          <div class="et_pb_text_inner">
                          <p>
                          SOMOS OS LÍDERES DE MERCADO DA ÁFRICA EM ALUGUEL, VENDAS, MANUTENÇÃO E TREINAMENTO DE SOLUÇÕES DE TRABALHO EM ALTURA E MANUSEIO DE MATERIAIS.
                          </p>
                          </div>
                          </div> <!-- .et_pb_text --><div class="et_pb_button_module_wrapper et_pb_button_0_wrapper et_pb_button_alignment_ et_pb_module ">
                          <a class="et_pb_button et_pb_button_0 button_quote et_animated et_pb_bg_layout_light" href="#form_quote">Entrar</a>
                          </div><div class="et_pb_module  et_pb_text et_pb_text_3 et_pb_bg_layout_light  et_pb_text_align_left">
                          
                          </div> <!-- .et_pb_text -->
                          </div> <!-- .et_pb_column --><div class="et_pb_column et_pb_column_1_2 et_pb_column_1  ds-vertical-align  et_pb_css_mix_blend_mode_passthrough">
                          
                          
                          <div class="et_pb_module  et_pb_code et_pb_code_0">
                          
                          
                          <div class="et_pb_code_inner">
                          
                          <!-- MasterSlider -->
                          <div id="P_MS5dbaada1daaf5" class="master-slider-parent msl ms-parent-id-2" style="max-width:100%;"  >
                          
                          
                          <!-- MasterSlider Main -->
                          <div id="MS5dbaada1daaf5" class="master-slider ms-skin-default" >
                          
                          <div  class="ms-slide" data-delay="3" data-fill-mode="fill"  >
                          <img src="https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/css/blank.gif" alt="" title="" data-src="https://www.eazi.co.za/wp-content/uploads/2018/06/Gallery-H800AJ-900x900.jpg" />
                            
                            
                            <div class="ms-thumb" ><div class="ms-tab-context"><div class=&quot;ms-tab-context&quot;></div></div>
                            </div>
                            </div>
                            <div  class="ms-slide" data-delay="3" data-fill-mode="fill"  >
                            <img src="https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/css/blank.gif" alt="" title="" data-src="https://www.eazi.co.za/wp-content/uploads/2019/10/135-HD-Web-Banner-1-900x900.jpg" />
                              
                              
                              <div class="ms-thumb" ><div class="ms-tab-context"><div class=&quot;ms-tab-context&quot;></div></div>
                              </div>
                              </div>
                              <div  class="ms-slide" data-delay="3" data-fill-mode="fill"  >
                              <img src="https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/css/blank.gif" alt="" title="" data-src="https://www.eazi.co.za/wp-content/uploads/2019/05/Linde-Home-Page-Rotational-Banner-900x900.jpg" />
                                
                                
                                <div class="ms-thumb" ><div class="ms-tab-context"><div class=&quot;ms-tab-context&quot;></div></div>
                                </div>
                                </div>
                                <div  class="ms-slide" data-delay="3" data-fill-mode="fill"  >
                                <img src="https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/css/blank.gif" alt="" title="" data-src="https://www.eazi.co.za/wp-content/uploads/2018/07/hero-maeda-indoor-01-900x900.jpg" />
                                  
                                  
                                  <div class="ms-thumb" ><div class="ms-tab-context"><div class=&quot;ms-tab-context&quot;></div></div>
                                  </div>
                                  </div>
                                  <div  class="ms-slide" data-delay="3" data-fill-mode="fill"  >
                                  <img src="https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/css/blank.gif" alt="" title="" data-src="https://www.eazi.co.za/wp-content/uploads/2018/07/hero-magni-outdoor-01-900x900.jpg" />
                                    
                                    
                                    <div class="ms-thumb" ><div class="ms-tab-context"><div class=&quot;ms-tab-context&quot;></div></div>
                                    </div>
                                    </div>
                                    
                                    </div>
                                    <!-- END MasterSlider Main -->
                                    
                                    
                                    </div>
                                    <!-- END MasterSlider -->
                                    
                                    <script>
                                    (function ( $ ) {
                                      "use strict";
                                      
                                      $(function () {
                                        var masterslider_aaf5 = new MasterSlider();
                                        
                                        // slider controls
                                        
                                        // slider setup
                                        masterslider_aaf5.setup("MS5dbaada1daaf5", {
                                          width           : 900,
                                          height          : 900,
                                          minHeight       : 0,
                                          space           : 0,
                                          start           : 1,
                                          grabCursor      : false,
                                          swipe           : false,
                                          mouse           : false,
                                          layout          : "boxed",
                                          wheel           : false,
                                          autoplay        : true,
                                          instantStartLayers:false,
                                          loop            : true,
                                          shuffle         : false,
                                          preload         : 0,
                                          heightLimit     : true,
                                          autoHeight      : true,
                                          smoothHeight    : true,
                                          endPause        : false,
                                          overPause       : false,
                                          fillMode        : "fill",
                                          centerControls  : true,
                                          startOnAppear   : false,
                                          layersMode      : "center",
                                          hideLayers      : false,
                                          fullscreenMargin: 0,
                                          speed           : 20,
                                          dir             : "h",
                                          parallaxMode    : 'swipe',
                                          view            : "fade"
                                        });
                                        
                                        
                                        window.masterslider_instances = window.masterslider_instances || [];
                                        window.masterslider_instances.push( masterslider_aaf5 );
                                      });
                                      
                                    })(jQuery);
                                    </script>
                                    
                                    
                                    </div> <!-- .et_pb_code_inner -->
                                    </div> <!-- .et_pb_code -->
                                    </div> <!-- .et_pb_column -->
                                    
                                    
                                    </div> <!-- .et_pb_row -->
                                    
                                    
                                    </div> <!-- .et_pb_section -->
                                    
                                    
                                    <div id="form_quote" class="et_pb_section et_pb_section_12 et_section_regular">
                                    
                                    
                                    
                                    
                                    <div class="et_pb_row et_pb_row_15">
                                    <div class="et_pb_column et_pb_column_4_4 et_pb_column_30    et_pb_css_mix_blend_mode_passthrough et-last-child">
                                    
                                    
                                    <div class="et_pb_module  et_pb_text et_pb_text_21 et_pb_bg_layout_light  et_pb_text_align_left">
                                    
                                    
                                    <div class="et_pb_text_inner">
                                    <h2>Get A Quote… Start Here</h2>
                                    </div>
                                    </div> <!-- .et_pb_text --><div class="et_pb_module et_pb_text et_pb_text_22 brand-logos et_pb_bg_layout_light  et_pb_text_align_center">
                                    
                                    
                                    <div class="et_pb_text_inner">
                                    <p><img src="/wp-content/uploads/2018/09/jlg.svg" alt="JLG logo" /><img src="/wp-content/uploads/2018/10/jcb.svg" alt="JCB logo" /></p>
                                    <p><img src="/wp-content/uploads/2019/05/LMH_Logo_RGB.svg" alt="Linde logo" /><img src="/wp-content/uploads/2018/09/magni.svg" alt="Magni logo" /></p>
                                    </div>
                                    </div> <!-- .et_pb_text -->
                                    </div> <!-- .et_pb_column -->
                                    
                                    
                                    </div> <!-- .et_pb_row --><div class="et_pb_row et_pb_row_16">
                                    <div class="et_pb_column et_pb_column_4_4 et_pb_column_31    et_pb_css_mix_blend_mode_passthrough et-last-child">
                                    
                                    
                                    <div class="et_pb_module et_pb_code et_pb_code_2 quote-form-wrapper">
                                    
                                    
                                    <div class="et_pb_code_inner">
                                    
                                    <div class='gf_browser_chrome gform_wrapper' id='gform_wrapper_1' style='display:none'><a id='gf_1' class='gform_anchor' ></a><form method='post' enctype='multipart/form-data' target='gform_ajax_frame_1' id='gform_1'  action='/#gf_1'>
                                    <div class='gform_body'><ul id='gform_fields_1' class='gform_fields top_label form_sublabel_above description_below'><li id='field_1_18'  class='gfield gform_hidden field_sublabel_above field_description_below gfield_visibility_visible' ><input name='input_18' id='input_1_18' type='hidden' class='gform_hidden'  aria-invalid="false" value='' /></li><li id='field_1_17'  class='gfield lookingfor field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_17' >Looking for</label><div class='ginput_container ginput_container_select'><select name='input_17' id='input_1_17' onchange='gf_apply_rules(1,[5,6,7,8,9,10]);' class='large gfield_select'    aria-invalid="false"><option value='' selected='selected' class='gf_placeholder'>--select--</option><option value='Rental' >Rental</option><option value='Buy' >Buy</option><option value='Service' >Service</option><option value='Training' >Training</option></select></div></li><li id='field_1_1'  class='gfield gf_left_half et_pb_contact_field gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_1' >Name<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_text'><input name='input_1' id='input_1_1' type='text' value='' class='medium'    placeholder='Name' aria-required="true" aria-invalid="false" /></div></li><li id='field_1_2'  class='gfield gf_right_half et_pb_contact_field gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_2' >Email Address<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_email'>
                                    <input name='input_2' id='input_1_2' type='text' value='' class='medium'    placeholder='Email Address' aria-required="true" aria-invalid="false"/>
                                    </div></li><li id='field_1_3'  class='gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_3' >Contact Number<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_phone'><input name='input_3' id='input_1_3' type='text' value='' class='medium'   placeholder='Contact Number' aria-required="true" aria-invalid="false" /></div></li><li id='field_1_4'  class='gfield gf_right_half field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_4' >Company</label><div class='ginput_container ginput_container_text'><input name='input_4' id='input_1_4' type='text' value='' class='medium'    placeholder='Company'  aria-invalid="false" /></div></li><li id='field_1_15'  class='gfield gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_15_1' >Country<span class='gfield_required'>*</span></label><div class='ginput_container horizontal medium gfield_chainedselect' id='input_1_15'><span id='input_1_15_1_container' class=''>
                                    <select name='input_15.1' id='input_1_15_1' class='' onchange="gf_input_change( this, 1, 15 );"  ><option value=''  class='gf_placeholder'>Country</option><option value='South Africa' >South Africa</option><option value='Botswana' >Botswana</option><option value='Mozambique' >Mozambique</option><option value='Namibia' >Namibia</option><option value='Zambia' >Zambia</option><option value='Zimbabwe' >Zimbabwe</option></select>
                                    </span><span id='input_1_15_2_container' class=''>
                                    <select name='input_15.2' id='input_1_15_2' class='' onchange="gf_input_change( this, 1, 15 );"  ><option value=''  class='gf_placeholder'>City</option></select>
                                    </span><span class="gf_chain_complete" style="display:none;">&nbsp;</span></div></li><li id='field_1_16'  class='gfield field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_16' >City - Other</label><div class='ginput_container ginput_container_text'><input name='input_16' id='input_1_16' type='text' value='' class='large'    placeholder='Other'  aria-invalid="false" /></div></li><li id='field_1_5'  class='gfield field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_5' >Site Address Where Machine is Required</label><div class='ginput_container ginput_container_text'><input name='input_5' id='input_1_5' type='text' value='' class='large'   onchange='gf_apply_rules(1,[5]);' onkeyup='clearTimeout(__gf_timeout_handle); __gf_timeout_handle = setTimeout("gf_apply_rules(1,[5])", 300);' placeholder='Site Address Where Machine is Required'  aria-invalid="false" /></div></li><li id='field_1_6'  class='gfield select-focus gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_6' >Equipment Selector<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_select'><select name='input_6' id='input_1_6' onchange='gf_apply_rules(1,[6,7,8,11,12,13,14]);' class='large gfield_select'   aria-required="true" aria-invalid="false"><option value='Equipment Selector' selected='selected'>Equipment Selector</option><option value='I know what equipment I need…' >I know what equipment I need…</option><option value='Help me choose what I need…' >Help me choose what I need…</option></select></div></li><li id='field_1_7'  class='gfield gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_7' >Equipment Name<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_text'><input name='input_7' id='input_1_7' type='text' value='' class='large'   onchange='gf_apply_rules(1,[7]);' onkeyup='clearTimeout(__gf_timeout_handle); __gf_timeout_handle = setTimeout("gf_apply_rules(1,[7])", 300);' placeholder='Equipment Name' aria-required="true" aria-invalid="false" /></div></li><li id='field_1_8'  class='gfield gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_8' >Details of Requirement<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_textarea'><textarea name='input_8' id='input_1_8' class='textarea large'  onchange='gf_apply_rules(1,[8]);' onkeyup='clearTimeout(__gf_timeout_handle); __gf_timeout_handle = setTimeout("gf_apply_rules(1,[8])", 300);' placeholder='Details of Requirement' aria-required="true" aria-invalid="false"   rows='10' cols='50'></textarea></div></li><li id='field_1_9'  class='gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_9' >Drop-off Date<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_date'>
                                    <input name='input_9' id='input_1_9' type='text' value='' class='datepicker medium ymd_dash datepicker_no_icon'   placeholder='Drop-off Date'/>
                                    </div>
                                    <input type='hidden' id='gforms_calendar_icon_input_1_9' class='gform_hidden' value='https://www.eazi.co.za/wp-content/plugins/gravityforms/images/calendar.png'/></li><li id='field_1_10'  class='gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_10' >Collection Date<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_date'>
                                      <input name='input_10' id='input_1_10' type='text' value='' class='datepicker medium ymd_dash datepicker_no_icon'   placeholder='Collection Date'/>
                                      </div>
                                      <input type='hidden' id='gforms_calendar_icon_input_1_10' class='gform_hidden' value='https://www.eazi.co.za/wp-content/plugins/gravityforms/images/calendar.png'/></li><li id='field_1_11'  class='gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_11' >Moving Needs<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_select'><select name='input_11' id='input_1_11'  class='medium gfield_select'   aria-required="true" aria-invalid="false"><option value='' selected='selected' class='gf_placeholder'>Moving Needs</option><option value='People' >People</option><option value='Material' >Material</option></select></div></li><li id='field_1_12'  class='gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_12' >Working Location<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_select'><select name='input_12' id='input_1_12'  class='medium gfield_select'   aria-required="true" aria-invalid="false"><option value='' selected='selected' class='gf_placeholder'>Working Location</option><option value='Mostly Outdoors (Engine Powered)' >Mostly Outdoors (Engine Powered)</option><option value='Mostly Indoor (Electric Powered)' >Mostly Indoor (Electric Powered)</option><option value='Outdoor &amp; Indoor' >Outdoor &amp; Indoor</option></select></div></li><li id='field_1_13'  class='gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_13' >Working Height<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_select'><select name='input_13' id='input_1_13'  class='medium gfield_select'   aria-required="true" aria-invalid="false"><option value='' selected='selected' class='gf_placeholder'>Working Height</option><option value='4.0—7.9 meters' >4.0—7.9 meters</option><option value='7.9—9.5 meters' >7.9—9.5 meters</option><option value='9.5—12.2 meters' >9.5—12.2 meters</option><option value='12.2—15.2 meters' >12.2—15.2 meters</option><option value='15.2—21.9 meters' >15.2—21.9 meters</option><option value='21.9—27.4 meters' >21.9—27.4 meters</option><option value='&gt; 27.4 meters' >&gt; 27.4 meters</option></select></div></li><li id='field_1_14'  class='gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible' ><label class='gfield_label' for='input_1_14' >Lifting Weight<span class='gfield_required'>*</span></label><div class='ginput_container ginput_container_select'><select name='input_14' id='input_1_14'  class='medium gfield_select'   aria-required="true" aria-invalid="false"><option value='' selected='selected' class='gf_placeholder'>Lifting Weight</option><option value='100—500 kg' >100—500 kg</option><option value='500—1500 kg' >500—1500 kg</option><option value='1500—3000 kg' >1500—3000 kg</option><option value='3000—5000 kg' >3000—5000 kg</option><option value='5000—15000 kg' >5000—15000 kg</option><option value='15000—30000 kg' >15000—30000 kg</option><option value='&gt; 30000 kg' >&gt; 30000 kg</option></select></div></li>
                                        </ul></div>
                                        <div class='gform_footer top_label'> <input type='submit' id='gform_submit_button_1' class='gform_button button' value='Submit'  onclick='if(window["gf_submitting_1"]){return false;}  window["gf_submitting_1"]=true;  ' onkeypress='if( event.keyCode == 13 ){ if(window["gf_submitting_1"]){return false;} window["gf_submitting_1"]=true;  jQuery("#gform_1").trigger("submit",[true]); }' /> <input type='hidden' name='gform_ajax' value='form_id=1&amp;title=&amp;description=&amp;tabindex=0' />
                                        <input type='hidden' class='gform_hidden' name='is_submit_1' value='1' />
                                        <input type='hidden' class='gform_hidden' name='gform_submit' value='1' />
                                        
                                        <input type='hidden' class='gform_hidden' name='gform_unique_id' value='' />
                                        <input type='hidden' class='gform_hidden' name='state_1' value='WyJbXSIsIjA0Mjg2MGQ4MGYwY2FkNjAyYzI4OGQwYTgwNWNmNzFmIl0=' />
                                        <input type='hidden' class='gform_hidden' name='gform_target_page_number_1' id='gform_target_page_number_1' value='0' />
                                        <input type='hidden' class='gform_hidden' name='gform_source_page_number_1' id='gform_source_page_number_1' value='1' />
                                        <input type='hidden' name='gform_field_values' value='' />
                                        
                                        </div>
                                        </form>
                                        </div>
                                        <iframe style='display:none;width:0px;height:0px;' src='about:blank' name='gform_ajax_frame_1' id='gform_ajax_frame_1'>This iframe contains the logic required to handle Ajax powered Gravity Forms.</iframe>
                                        <script type='text/javascript'>jQuery(document).ready(function($){gformInitSpinner( 1, 'https://www.eazi.co.za/wp-content/plugins/gravityforms/images/spinner.gif' );jQuery('#gform_ajax_frame_1').load( function(){var contents = jQuery(this).contents().find('*').html();var is_postback = contents.indexOf('GF_AJAX_POSTBACK') >= 0;if(!is_postback){return;}var form_content = jQuery(this).contents().find('#gform_wrapper_1');var is_confirmation = jQuery(this).contents().find('#gform_confirmation_wrapper_1').length > 0;var is_redirect = contents.indexOf('gformRedirect(){') >= 0;var is_form = form_content.length > 0 && ! is_redirect && ! is_confirmation;if(is_form){jQuery('#gform_wrapper_1').html(form_content.html());if(form_content.hasClass('gform_validation_error')){jQuery('#gform_wrapper_1').addClass('gform_validation_error');} else {jQuery('#gform_wrapper_1').removeClass('gform_validation_error');}setTimeout( function() { /* delay the scroll by 50 milliseconds to fix a bug in chrome */ jQuery(document).scrollTop(jQuery('#gform_wrapper_1').offset().top); }, 50 );if(window['gformInitDatepicker']) {gformInitDatepicker();}if(window['gformInitPriceFields']) {gformInitPriceFields();}var current_page = jQuery('#gform_source_page_number_1').val();gformInitSpinner( 1, 'https://www.eazi.co.za/wp-content/plugins/gravityforms/images/spinner.gif' );jQuery(document).trigger('gform_page_loaded', [1, current_page]);window['gf_submitting_1'] = false;}else if(!is_redirect){var confirmation_content = jQuery(this).contents().find('.GF_AJAX_POSTBACK').html();if(!confirmation_content){confirmation_content = contents;}setTimeout(function(){jQuery('#gform_wrapper_1').replaceWith(confirmation_content);jQuery(document).scrollTop(jQuery('#gf_1').offset().top);jQuery(document).trigger('gform_confirmation_loaded', [1]);window['gf_submitting_1'] = false;}, 50);}else{jQuery('#gform_1').append(contents);if(window['gformRedirect']) {gformRedirect();}}jQuery(document).trigger('gform_post_render', [1, current_page]);} );} );</script><script type='text/javascript'> if(typeof gf_global == 'undefined') var gf_global = {"gf_currency_config":{"name":"South African Rand","symbol_left":"R","symbol_right":"","symbol_padding":"","thousand_separator":",","decimal_separator":".","decimals":2},"base_url":"https:\/\/www.eazi.co.za\/wp-content\/plugins\/gravityforms","number_formats":[],"spinnerUrl":"https:\/\/www.eazi.co.za\/wp-content\/plugins\/gravityforms\/images\/spinner.gif"};jQuery(document).bind('gform_post_render', function(event, formId, currentPage){if(formId == 1) {gf_global["number_formats"][1] = {"18":{"price":false,"value":false},"17":{"price":false,"value":false},"1":{"price":false,"value":false},"2":{"price":false,"value":false},"3":{"price":false,"value":false},"4":{"price":false,"value":false},"15":{"price":false,"value":false},"16":{"price":false,"value":false},"5":{"price":false,"value":false},"6":{"price":false,"value":false},"7":{"price":false,"value":false},"8":{"price":false,"value":false},"9":{"price":false,"value":false},"10":{"price":false,"value":false},"11":{"price":false,"value":false},"12":{"price":false,"value":false},"13":{"price":false,"value":false},"14":{"price":false,"value":false}};if(window['jQuery']){if(!window['gf_form_conditional_logic'])window['gf_form_conditional_logic'] = new Array();window['gf_form_conditional_logic'][1] = { logic: { 16: {"field":{"actionType":"show","logicType":"any","rules":[{"fieldId":"15.1","operator":"is","value":"South Africa"},{"fieldId":"15.2","operator":"is","value":"Gauteng - Midrand"}]},"nextButton":null,"section":null},5: {"field":{"actionType":"show","logicType":"all","rules":[{"fieldId":5,"operator":"is","value":"__adv_cond_logic"},{"fieldId":17,"operator":"is","value":"__return_true"},{"fieldId":17,"operator":"is","value":"__return_true"},{"fieldId":18,"operator":"isnot","value":"__return_true"},{"fieldId":17,"operator":"is","value":"__return_true"},{"fieldId":18,"operator":"isnot","value":"__return_true"},{"fieldId":17,"operator":"is","value":"__return_true"},{"fieldId":18,"operator":"isnot","value":"__return_true"}]},"nextButton":null,"section":null},6: {"field":{"actionType":"show","logicType":"all","rules":[{"fieldId":6,"operator":"is","value":"__adv_cond_logic"},{"fieldId":17,"operator":"is","value":"__return_true"}]},"nextButton":null,"section":null},7: {"field":{"actionType":"show","logicType":"all","rules":[{"fieldId":7,"operator":"is","value":"__adv_cond_logic"},{"fieldId":17,"operator":"is","value":"__return_true"},{"fieldId":6,"operator":"is","value":"__return_true"},{"fieldId":17,"operator":"is","value":"__return_true"},{"fieldId":6,"operator":"is","value":"__return_true"},{"fieldId":17,"operator":"is","value":"__return_true"},{"fieldId":18,"operator":"is","value":"__return_true"},{"fieldId":17,"operator":"is","value":"__return_true"},{"fieldId":18,"operator":"is","value":"__return_true"}]},"nextButton":null,"section":null},8: {"field":{"actionType":"show","logicType":"all","rules":[{"fieldId":8,"operator":"is","value":"__adv_cond_logic"},{"fieldId":17,"operator":"is","value":"__return_true"},{"fieldId":6,"operator":"is","value":"__return_true"},{"fieldId":17,"operator":"is","value":"__return_true"},{"fieldId":6,"operator":"is","value":"__return_true"},{"fieldId":17,"operator":"is","value":"__return_true"},{"fieldId":18,"operator":"is","value":"__return_true"},{"fieldId":17,"operator":"is","value":"__return_true"},{"fieldId":18,"operator":"is","value":"__return_true"}]},"nextButton":null,"section":null},9: {"field":{"actionType":"show","logicType":"all","rules":[{"fieldId":"17","operator":"is","value":"Rental"}]},"nextButton":null,"section":null},10: {"field":{"actionType":"show","logicType":"all","rules":[{"fieldId":"17","operator":"is","value":"Rental"}]},"nextButton":null,"section":null},11: {"field":{"actionType":"show","logicType":"all","rules":[{"fieldId":"6","operator":"is","value":"Help me choose what I need\u2026"}]},"nextButton":null,"section":null},12: {"field":{"actionType":"show","logicType":"all","rules":[{"fieldId":"6","operator":"is","value":"Help me choose what I need\u2026"}]},"nextButton":null,"section":null},13: {"field":{"actionType":"show","logicType":"all","rules":[{"fieldId":"6","operator":"is","value":"Help me choose what I need\u2026"}]},"nextButton":null,"section":null},14: {"field":{"actionType":"show","logicType":"all","rules":[{"fieldId":"6","operator":"is","value":"Help me choose what I need\u2026"}]},"nextButton":null,"section":null} }, dependents: { 16: [16],5: [5],6: [6],7: [7],8: [8],9: [9],10: [10],11: [11],12: [12],13: [13],14: [14] }, animation: 0, defaults: {"6":"Equipment Selector"}, fields: {"18":[5,7,8],"17":[5,6,7,8,9,10],"1":[],"2":[],"3":[],"4":[],"15":[16],"16":[],"5":[5],"6":[6,7,8,11,12,13,14],"7":[7],"8":[8],"9":[],"10":[],"11":[],"12":[],"13":[],"14":[]} }; if(!window['gf_number_format'])window['gf_number_format'] = 'decimal_dot';jQuery(document).ready(function(){gf_apply_rules(1, [16,5,6,7,8,9,10,11,12,13,14], true);jQuery('#gform_wrapper_1').show();jQuery(document).trigger('gform_post_conditional_logic', [1, null, true]);} );} if(typeof Placeholders != 'undefined'){
                                          Placeholders.enable();
                                        }jQuery('#input_1_3').mask('(999) 999-9999').bind('keypress', function(e){if(e.which == 13){jQuery(this).blur();} } );;new GFChainedSelects( 1, 15, 0, "horizontal" );(function($){gf_datepicker_limit_past()})(jQuery);new GWAdvCondLogic( {"formId":1,"logic":{"5":{"actionType":"show","logicType":null,"groups":[{"actionType":"show","logicType":"all","rules":[{"fieldId":17,"operator":"is","value":"Rental"}]},{"actionType":"show","logicType":"all","rules":[{"fieldId":17,"operator":"is","value":"Buy"},{"fieldId":18,"operator":"isnot"}]},{"actionType":"show","logicType":"all","rules":[{"fieldId":17,"operator":"is","value":"Service"},{"fieldId":18,"operator":"isnot"}]},{"actionType":"show","logicType":"all","rules":[{"fieldId":17,"operator":"is","value":"Training"},{"fieldId":18,"operator":"isnot"}]}]},"6":{"actionType":"show","logicType":null,"groups":[{"actionType":"show","logicType":"all","rules":[{"fieldId":17,"operator":"is","value":"Rental"}]}]},"7":{"actionType":"show","logicType":null,"groups":[{"actionType":"show","logicType":"all","rules":[{"fieldId":17,"operator":"is","value":"Rental"},{"fieldId":6,"operator":"is","value":"Equipment Selector"}]},{"actionType":"show","logicType":"all","rules":[{"fieldId":17,"operator":"is","value":"Rental"},{"fieldId":6,"operator":"is","value":"I know what equipment I need\u2026"}]},{"actionType":"show","logicType":"all","rules":[{"fieldId":17,"operator":"is","value":"Buy"},{"fieldId":18,"operator":"is"}]},{"actionType":"show","logicType":"all","rules":[{"fieldId":17,"operator":"is","value":"Service"},{"fieldId":18,"operator":"is"}]}]},"8":{"actionType":"show","logicType":null,"groups":[{"actionType":"show","logicType":"all","rules":[{"fieldId":17,"operator":"is","value":"Rental"},{"fieldId":6,"operator":"is","value":"Equipment Selector"}]},{"actionType":"show","logicType":"all","rules":[{"fieldId":17,"operator":"is","value":"Rental"},{"fieldId":6,"operator":"is","value":"I know what equipment I need\u2026"}]},{"actionType":"show","logicType":"all","rules":[{"fieldId":17,"operator":"is","value":"Buy"},{"fieldId":18,"operator":"is"}]},{"actionType":"show","logicType":"all","rules":[{"fieldId":17,"operator":"is","value":"Service"},{"fieldId":18,"operator":"is"}]}]}}} );} } );jQuery(document).bind('gform_post_conditional_logic', function(event, formId, fields, isInit){} );</script><script type='text/javascript'> jQuery(document).ready(function(){jQuery(document).trigger('gform_post_render', [1, 1]) } ); </script>
                                        </div> <!-- .et_pb_code_inner -->
                                        </div> <!-- .et_pb_code -->
                                        </div> <!-- .et_pb_column -->
                                        
                                        
                                        </div> <!-- .et_pb_row --><div class="et_pb_row et_pb_row_17 et_pb_equal_columns">
                                        <div class="et_pb_column et_pb_column_1_6 et_pb_column_32  ds-vertical-align  et_pb_css_mix_blend_mode_passthrough et_pb_column_empty">
                                        
                                        
                                        
                                        </div> <!-- .et_pb_column --><div class="et_pb_column et_pb_column_1_6 et_pb_column_33  ds-vertical-align  et_pb_css_mix_blend_mode_passthrough et_pb_column_empty">
                                        
                                        
                                        
                                        </div> <!-- .et_pb_column --><div class="et_pb_column et_pb_column_1_6 et_pb_column_34  ds-vertical-align  et_pb_css_mix_blend_mode_passthrough et_pb_column_empty">
                                        
                                        
                                        
                                        </div> <!-- .et_pb_column --><div class="et_pb_column et_pb_column_1_6 et_pb_column_35  ds-vertical-align  et_pb_css_mix_blend_mode_passthrough et_pb_column_empty">
                                        
                                        
                                        
                                        </div> <!-- .et_pb_column --><div class="et_pb_column et_pb_column_1_6 et_pb_column_36  ds-vertical-align  et_pb_css_mix_blend_mode_passthrough et_pb_column_empty">
                                        
                                        
                                        
                                        </div> <!-- .et_pb_column --><div class="et_pb_column et_pb_column_1_6 et_pb_column_37  ds-vertical-align  et_pb_css_mix_blend_mode_passthrough et_pb_column_empty">
                                        
                                        
                                        
                                        </div> <!-- .et_pb_column -->
                                        
                                        
                                        </div> <!-- .et_pb_row -->
                                        
                                        
                                        </div> <!-- .et_pb_section --></div>
                                        
                                        </div>					</div> <!-- .entry-content -->
                                        
                                        
                                        </article> <!-- .et_pb_post -->
                                        
                                        
                                        
                                        </div> <!-- #main-content -->
                                        
                                        
                                        <span class="et_pb_scroll_top et-pb-icon"></span>
                                        
                                        
                                        <footer id="main-footer">
                                        
                                        <div class="container">
                                        <div id="footer-widgets" class="clearfix">
                                        <div class="footer-widget"><div id="text-4" class="fwidget et_pb_widget widget_text"><h4 class="title">Contact</h4>			<div class="textwidget"><p>South Africa: <a href="tel:+27861003294">+27 86 100 3294</a><br />
                                        Mozambique: <a href="tel:+258872115809">+258 87 211 5809</a><br />
                                        Namibia: <a href="tel:+2648193294">+264 81 9 3294</a><br />
                                        Zambia: <a href="tel:+27794900775">+27 79 490 0775</a><br />
                                        Zimbabwe: <a href="tel:+263787228781">+263 78 722 8781</a><br />
                                        Email: <a href="mailto:info@eazi.co.za">info@eazi.co.za</a></p>
                                        </div>
                                        </div> <!-- end .fwidget --></div> <!-- end .footer-widget --><div class="footer-widget"><div id="text-2" class="fwidget et_pb_widget widget_text"><h4 class="title">Address</h4>			<div class="textwidget"><p>Allandale Offices<br />
                                        23 Magwa Crescent<br />
                                        Waterfall City<br />
                                        2090</p>
                                        </div>
                                        </div> <!-- end .fwidget --></div> <!-- end .footer-widget --><div class="footer-widget"><div id="text-3" class="fwidget et_pb_widget widget_text"><h4 class="title">Legal</h4>			<div class="textwidget"><p><a href="/terms-of-service/">Terms of Service</a><br />
                                        <a href="/disclaimer/">Disclaimer</a><br />
                                        <a href="/wp-content/uploads/2020/04/Eazi_Access_Rental_-_Final_Certificate_and_Detailed_Scorecard-2020.pdf" target="_blank" rel="noopener noreferrer">BBBEE</a><br />
                                        <a href="/wp-content/uploads/2020/05/EAR_Letter_of_Good_Standing_2020.pdf" target="_blank" rel="noopener noreferrer">Letter of Good Standing</a><br />
                                        <a href="/wp-content/uploads/2020/05/EAR_Tax_Clearance_Pin_2020.pdf" target="_blank" rel="noopener noreferrer">Tax Clearance Pin</a></p>
                                        </div>
                                        </div> <!-- end .fwidget --></div> <!-- end .footer-widget --><div class="footer-widget"><div id="glt_widget-2" class="fwidget et_pb_widget widget_glt_widget"><h4 class="title">Language</h4><div id="flags" class="size24"><ul id="sortable" class="ui-sortable" style="float:left"><li id="English"><a href="#" title="English" class="nturl notranslate en flag English"></a></li><li id="French"><a href="#" title="French" class="nturl notranslate fr flag French"></a></li><li id="Portuguese"><a href="#" title="Portuguese" class="nturl notranslate pt flag Portuguese"></a></li><li id="German"><a href="#" title="German" class="nturl notranslate de flag German"></a></li></ul></div><div id="google_language_translator" class="default-language-en"></div></div> <!-- end .fwidget --></div> <!-- end .footer-widget -->    </div> <!-- #footer-widgets -->
                                        </div>    <!-- .container -->
                                        
                                        
                                        <div id="footer-bottom">
                                        <div class="container clearfix">
                                        <div id="footer-info">Eazi Access © 2018 — All Rights Reserved.</div>					</div>	<!-- .container -->
                                        </div>
                                        </footer> <!-- #main-footer -->
                                        </div> <!-- #et-main-area -->
                                        
                                        
                                        </div> <!-- #page-container -->
                                        
                                        
                                        <script>    
                                        
                                        jQuery(document).ready(function() {
                                          
                                          if (jQuery('.button_quote').length > 0) {
                                            
                                            jQuery('.button_quote').off('click');
                                            jQuery('.button_quote').on('click', function(e) {
                                              
                                              var product_title = jQuery(e.currentTarget).data('product');
                                              
                                              console.log('button_quote click: ', e.currentTarget);
                                              console.log('product_title: ', product_title);
                                              
                                              jQuery('#form_quote').css('display', 'block');
                                              
                                              if (typeof product_title != 'undefined' && product_title != '') {
                                                jQuery('#input_1_6').val('I know what equipment I need…').trigger('change');            
                                                jQuery('#input_1_7').val(product_title);
                                              }
                                              
                                            });
                                            
                                          }
                                          
                                        });
                                        
                                        </script>
                                        <script>
                                        
                                        function gf_datepicker_limit_past() {
                                          
                                          
                                          /**
                                          * Gravity Form Hooks
                                          */
                                          // Disable Past Dates.
                                          gform.addFilter( 'gform_datepicker_options_pre_init', function( optionsObj, formId, fieldId ) {
                                            // Apply to field 2 only 
                                            if ( formId == 1 && (fieldId == 9 || fieldId == 10) ) {
                                              optionsObj.minDate = 0;
                                            }
                                            return optionsObj;
                                          });  
                                          
                                          
                                          
                                        }
                                        
                                        
                                        
                                        </script>
                                        <script type="text/javascript">
                                        var et_animation_data = [{"class":"et_pb_text_0","style":"slideBottom","repeat":"once","duration":"1000ms","delay":"0ms","intensity":"50%","starting_opacity":"0%","speed_curve":"ease-in-out"},{"class":"et_pb_text_1","style":"fade","repeat":"once","duration":"1000ms","delay":"0ms","intensity":"50%","starting_opacity":"0%","speed_curve":"ease-in-out"},{"class":"et_pb_text_2","style":"slideTop","repeat":"once","duration":"1000ms","delay":"0ms","intensity":"17%","starting_opacity":"0%","speed_curve":"ease-in-out"},{"class":"et_pb_button_0","style":"zoom","repeat":"once","duration":"1000ms","delay":"500ms","intensity":"50%","starting_opacity":"0%","speed_curve":"ease-in-out"},{"class":"et_pb_button_1","style":"slide","repeat":"once","duration":"1000ms","delay":"0ms","intensity":"50%","starting_opacity":"0%","speed_curve":"ease-in-out"},{"class":"et_pb_button_2","style":"slide","repeat":"once","duration":"1000ms","delay":"0ms","intensity":"50%","starting_opacity":"0%","speed_curve":"ease-in-out"},{"class":"et_pb_text_10","style":"fade","repeat":"once","duration":"1000ms","delay":"0ms","intensity":"50%","starting_opacity":"0%","speed_curve":"ease-in-out"},{"class":"et_pb_button_3","style":"flipRight","repeat":"once","duration":"1000ms","delay":"0ms","intensity":"20%","starting_opacity":"0%","speed_curve":"ease-in-out"},{"class":"et_pb_text_23","style":"fade","repeat":"once","duration":"1000ms","delay":"0ms","intensity":"50%","starting_opacity":"0%","speed_curve":"ease-in-out"},{"class":"et_pb_text_24","style":"fade","repeat":"once","duration":"1000ms","delay":"0ms","intensity":"50%","starting_opacity":"0%","speed_curve":"ease-in-out"},{"class":"et_pb_text_25","style":"fade","repeat":"once","duration":"1000ms","delay":"0ms","intensity":"50%","starting_opacity":"0%","speed_curve":"ease-in-out"}];
                                        </script>
                                        <!-- Google Tag Manager (noscript) -->
                                        
                                        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TLRR726" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
                                          <!-- End Google Tag Manager (noscript) -->
                                          
                                          <!-- Global Site Tag (gtag.js) - Google Analytics -->
                                          <script async src="https://www.googletagmanager.com/gtag/js?id=UA-35197551-1"></script>
                                          <script>
                                          window.dataLayer = window.dataLayer || [];
                                          function gtag(){dataLayer.push(arguments)};
                                          gtag('js', new Date());
                                          
                                          gtag('config', 'UA-35197551-1');
                                          </script> 
                                          <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/google-language-translator/js/scripts.js?ver=6.0.6' id='scripts-js'></script>
                                          <script type='text/javascript' src='//translate.google.com/translate_a/element.js?cb=GoogleLanguageTranslatorInit' id='scripts-google-js'></script>
                                          <script type='text/javascript' id='google-invisible-recaptcha-js-before'>
                                          var renderInvisibleReCaptcha = function() {
                                            
                                            for (var i = 0; i < document.forms.length; ++i) {
                                              var form = document.forms[i];
                                              var holder = form.querySelector('.inv-recaptcha-holder');
                                              
                                              if (null === holder) continue;
                                              holder.innerHTML = '';
                                              
                                              (function(frm){
                                                var cf7SubmitElm = frm.querySelector('.wpcf7-submit');
                                                var holderId = grecaptcha.render(holder,{
                                                  'sitekey': '6LeFeH0UAAAAADwKEI8eb_j4fHDi1nAZUNr8BNOa', 'size': 'invisible', 'badge' : 'bottomright',
                                                  'callback' : function (recaptchaToken) {
                                                    if((null !== cf7SubmitElm) && (typeof jQuery != 'undefined')){jQuery(frm).submit();grecaptcha.reset(holderId);return;}
                                                    HTMLFormElement.prototype.submit.call(frm);
                                                  },
                                                  'expired-callback' : function(){grecaptcha.reset(holderId);}
                                                });
                                                
                                                if(null !== cf7SubmitElm && (typeof jQuery != 'undefined') ){
                                                  jQuery(cf7SubmitElm).off('click').on('click', function(clickEvt){
                                                    clickEvt.preventDefault();
                                                    grecaptcha.execute(holderId);
                                                  });
                                                }
                                                else
                                                {
                                                  frm.onsubmit = function (evt){evt.preventDefault();grecaptcha.execute(holderId);};
                                                }
                                                
                                                
                                              })(form);
                                            }
                                          };
                                          </script>
                                          <script type='text/javascript' async defer src='https://www.google.com/recaptcha/api.js?onload=renderInvisibleReCaptcha&#038;render=explicit' id='google-invisible-recaptcha-js'></script>
                                          <script type='text/javascript' id='divi-custom-script-js-extra'>
                                          /* <![CDATA[ */
                                          var DIVI = {"item_count":"%d Item","items_count":"%d Items"};
                                          var et_shortcodes_strings = {"previous":"Previous","next":"Next"};
                                          var et_pb_custom = {"ajaxurl":"https:\/\/www.eazi.co.za\/wp-admin\/admin-ajax.php","images_uri":"https:\/\/www.eazi.co.za\/wp-content\/themes\/Divi\/images","builder_images_uri":"https:\/\/www.eazi.co.za\/wp-content\/themes\/Divi\/includes\/builder\/images","et_frontend_nonce":"80b69d47a9","subscription_failed":"Please, check the fields below to make sure you entered the correct information.","et_ab_log_nonce":"ace18afdca","fill_message":"Please, fill in the following fields:","contact_error_message":"Please, fix the following errors:","invalid":"Invalid email","captcha":"Captcha","prev":"Prev","previous":"Previous","next":"Next","wrong_captcha":"You entered the wrong number in captcha.","ignore_waypoints":"no","is_divi_theme_used":"1","widget_search_selector":".widget_search","is_ab_testing_active":"","page_id":"37","unique_test_id":"","ab_bounce_rate":"5","is_cache_plugin_active":"yes","is_shortcode_tracking":"","tinymce_uri":""};
                                          var et_pb_box_shadow_elements = [];
                                          /* ]]> */
                                          </script>
                                          <script type='text/javascript' src='https://www.eazi.co.za/wp-content/themes/Divi/js/custom.min.js?ver=3.19.15' id='divi-custom-script-js'></script>
                                          <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/miguras-divi-enhancer/scripts/frontend-bundle.min.js?ver=1.0.0' id='divi-enhancer-frontend-bundle-js'></script>
                                          <script type='text/javascript' src='https://www.eazi.co.za/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4' id='jquery-ui-core-js'></script>
                                          <script type='text/javascript' src='https://www.eazi.co.za/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4' id='jquery-ui-datepicker-js'></script>
                                          <script type='text/javascript' id='jquery-ui-datepicker-js-after'>
                                          jQuery(document).ready(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"dd\/mm\/yy","firstDay":1,"isRTL":false});});
                                          </script>
                                          <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/gravityforms/js/datepicker.min.js?ver=2.3.1' id='gform_datepicker_init-js'></script>
                                          <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/js/jquery.easing.min.js?ver=3.5.8' id='jquery-easing-js'></script>
                                          <script type='text/javascript' src='https://www.eazi.co.za/wp-content/plugins/master-slider/public/assets/js/masterslider.min.js?ver=3.5.8' id='masterslider-core-js'></script>
                                          <script type='text/javascript' src='https://www.eazi.co.za/wp-content/themes/Divi/core/admin/js/common.js?ver=3.19.15' id='et-core-common-js'></script>
                                          <script type='text/javascript' src='https://www.eazi.co.za/wp-content/themes/Divi-Eazi/js/custom.js?ver=201908271856' id='custom-child-js-js'></script>
                                          <script type='text/javascript' src='https://www.eazi.co.za/wp-includes/js/wp-embed.min.js?ver=5.5.1' id='wp-embed-js'></script>
                                          </body>
                                          </html>
                                          
                                          <!-- Performance optimized by Redis Object Cache. Learn more: https://wprediscache.com -->
                                            