<!-- FORMULARIO -->

<div id="form_quote" class="et_pb_section et_pb_section_9 et_section_regular" style="display: block;">
    <div class="et_pb_row et_pb_row_13">
        <div
            class="et_pb_column et_pb_column_4_4 et_pb_column_27    et_pb_css_mix_blend_mode_passthrough et-last-child">

            <div class="et_pb_module  et_pb_text et_pb_text_20 et_pb_bg_layout_light  et_pb_text_align_left">

                <div class="et_pb_text_inner">
                    <h2 style="text-align: center;">
                        <font style="vertical-align: inherit;">
                            <font class="" style="vertical-align: inherit;">Entrar</font>
                        </font>
                    </h2>
                </div>
            </div> <!-- .et_pb_text -->
        </div> <!-- .et_pb_column -->

    </div> <!-- .et_pb_row -->
    <div class="et_pb_row et_pb_row_14">
        <div
            class="et_pb_column et_pb_column_4_4 et_pb_column_28    et_pb_css_mix_blend_mode_passthrough et-last-child">

            <div class="et_pb_module et_pb_code et_pb_code_2 quote-form-wrapper">

                <div class="et_pb_code_inner">

                    <div class="gf_browser_chrome gform_wrapper" id="gform_wrapper_1" style=""><a id="gf_1"
                            class="gform_anchor"></a>
                        <form method="post" enctype="multipart/form-data" target="gform_ajax_frame_1" id="gform_1"
                            action="/rent/#gf_1">
                            <div class="gform_body">
                                <ul id="gform_fields_1"
                                    class="gform_fields top_label form_sublabel_above description_below">
                                    <li id="field_1_18"
                                        class="gfield gform_hidden field_sublabel_above field_description_below gfield_visibility_visible">
                                        <input name="input_18" id="input_1_18" type="hidden" class="gform_hidden"
                                            aria-invalid="false" value="">
                                    </li>


                                    <li id="field_1_1"
                                        class="gfield gf_left_half et_pb_contact_field gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible">
                                        <label class="gfield_label" for="input_1_1">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Nome </font>
                                            </font><span class="gfield_required">
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">*</font>
                                                </font>
                                            </span>
                                        </label>
                                        <div class="ginput_container ginput_container_text"><input name="input_1"
                                                id="input_1_1" type="text" value="" class="medium" placeholder="Nome"
                                                aria-required="true" aria-invalid="false"></div>
                                    </li>
                                    <li id="field_1_2"
                                        class="gfield gf_right_half et_pb_contact_field gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible">
                                        <label class="gfield_label" for="input_1_2">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Endereço de Email </font>
                                            </font><span class="gfield_required">
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">*</font>
                                                </font>
                                            </span>
                                        </label>
                                        <div class="ginput_container ginput_container_email">
                                            <input name="input_2" id="input_1_2" type="text" value="" class="medium"
                                                placeholder="Endereço de e-mail" aria-required="true"
                                                aria-invalid="false">
                                        </div>
                                    </li>
                                    <li id="field_1_3"
                                        class="gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible">
                                        <label class="gfield_label" for="input_1_3">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Número de contato </font>
                                            </font><span class="gfield_required">
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">*</font>
                                                </font>
                                            </span>
                                        </label>
                                        <div class="ginput_container ginput_container_phone"><input name="input_3"
                                                id="input_1_3" type="text" value="" class="medium"
                                                placeholder="Número de contato" aria-required="true"
                                                aria-invalid="false"></div>
                                    </li>
                                    <li id="field_1_4"
                                        class="gfield gf_right_half field_sublabel_above field_description_below gfield_visibility_visible">
                                        <label class="gfield_label" for="input_1_4">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Companhia</font>
                                            </font>
                                        </label>
                                        <div class="ginput_container ginput_container_text"><input name="input_4"
                                                id="input_1_4" type="text" value="" class="medium"
                                                placeholder="Companhia" aria-invalid="false"></div>
                                    </li>
                                    <li id="field_1_15"
                                        class="gfield gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible">
                                        <label class="gfield_label" for="input_1_15_1">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">País </font>
                                            </font><span class="gfield_required">
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">*</font>
                                                </font>
                                            </span>
                                        </label>
                                        <div class="ginput_container horizontal medium gfield_chainedselect"
                                            id="input_1_15"><span id="input_1_15_1_container" class="">
                                                <select name="input_15.1" id="input_1_15_1" class=""
                                                    onchange="gf_input_change( this, 1, 15 );">
                                                    <option value="" class="gf_placeholder">
                                                        <font style="vertical-align: inherit;">
                                                            <font style="vertical-align: inherit;">País</font>
                                                        </font>
                                                    </option>
                                                    <option value="South Africa">
                                                        <font style="vertical-align: inherit;">
                                                            <font style="vertical-align: inherit;">África do Sul</font>
                                                        </font>
                                                    </option>
                                                    <option value="Botswana">
                                                        <font style="vertical-align: inherit;">
                                                            <font style="vertical-align: inherit;">Botswana</font>
                                                        </font>
                                                    </option>
                                                    <option value="Mozambique">
                                                        <font style="vertical-align: inherit;">
                                                            <font style="vertical-align: inherit;">Moçambique</font>
                                                        </font>
                                                    </option>
                                                    <option value="Namibia">
                                                        <font style="vertical-align: inherit;">
                                                            <font style="vertical-align: inherit;">Namibia</font>
                                                        </font>
                                                    </option>
                                                    <option value="Zambia">
                                                        <font style="vertical-align: inherit;">
                                                            <font style="vertical-align: inherit;">Zâmbia</font>
                                                        </font>
                                                    </option>
                                                    <option value="Zimbabwe">
                                                        <font style="vertical-align: inherit;">
                                                            <font style="vertical-align: inherit;">Zimbábue</font>
                                                        </font>
                                                    </option>
                                                </select>
                                            </span><span id="input_1_15_2_container" class="">
                                                <select name="input_15.2" id="input_1_15_2" class=""
                                                    onchange="gf_input_change( this, 1, 15 );" disabled="">
                                                    <option value="" class="gf_placeholder">
                                                        <font style="vertical-align: inherit;">
                                                            <font style="vertical-align: inherit;">Cidade</font>
                                                        </font>
                                                    </option>
                                                </select>
                                            </span><span class="gf_chain_complete" style="display:none;">&nbsp;</span>
                                        </div>
                                    </li>
                                    <li id="field_1_16"
                                        class="gfield field_sublabel_above field_description_below gfield_visibility_visible"
                                        style="display: none;"><label class="gfield_label" for="input_1_16">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Cidade - Outro</font>
                                            </font>
                                        </label>
                                        <div class="ginput_container ginput_container_text"><input name="input_16"
                                                id="input_1_16" type="text" value="" class="large"
                                                placeholder="De outros" aria-invalid="false" disabled=""></div>
                                    </li>
                                    <li id="field_1_5"
                                        class="gfield field_sublabel_above field_description_below gfield_visibility_visible"
                                        style="display: none;"><label class="gfield_label" for="input_1_5">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Endereço do local onde a máquina
                                                    é necessária</font>
                                            </font>
                                        </label>
                                        <div class="ginput_container ginput_container_text"><input name="input_5"
                                                id="input_1_5" type="text" value="" class="large"
                                                onchange="gf_apply_rules(1,[5]);"
                                                onkeyup="clearTimeout(__gf_timeout_handle); __gf_timeout_handle = setTimeout(&quot;gf_apply_rules(1,[5])&quot;, 300);"
                                                placeholder="Endereço do local onde a máquina é necessária"
                                                aria-invalid="false" disabled=""></div>
                                    </li>
                                    <li id="field_1_6"
                                        class="gfield select-focus gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible"
                                        style="display: none;"><label class="gfield_label" for="input_1_6">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Seletor de equipamento </font>
                                            </font><span class="gfield_required">
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">*</font>
                                                </font>
                                            </span>
                                        </label>
                                        <div class="ginput_container ginput_container_select"><select name="input_6"
                                                id="input_1_6" onchange="gf_apply_rules(1,[6,7,8,11,12,13,14]);"
                                                class="large gfield_select" aria-required="true" aria-invalid="false">
                                                <option value="Equipment Selector" selected="selected">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">Seletor de Equipamento
                                                        </font>
                                                    </font>
                                                </option>
                                                <option value="I know what equipment I need…">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">Eu sei de que equipamento
                                                            preciso ...</font>
                                                    </font>
                                                </option>
                                                <option value="Help me choose what I need…">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">Ajude-me a escolher o que
                                                            preciso ...</font>
                                                    </font>
                                                </option>
                                            </select></div>
                                    </li>
                                    <li id="field_1_7"
                                        class="gfield gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible"
                                        style="display: list-item;"><label class="gfield_label" for="input_1_7">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Nome do equipamento </font>
                                            </font><span class="gfield_required">
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">*</font>
                                                </font>
                                            </span>
                                        </label>
                                        <div class="ginput_container ginput_container_text"><input name="input_7"
                                                id="input_1_7" type="text" value="" class="large"
                                                onchange="gf_apply_rules(1,[7]);"
                                                onkeyup="clearTimeout(__gf_timeout_handle); __gf_timeout_handle = setTimeout(&quot;gf_apply_rules(1,[7])&quot;, 300);"
                                                placeholder="nome do equipamento" aria-required="true"
                                                aria-invalid="false"></div>
                                    </li>
                                    <li id="field_1_8"
                                        class="gfield gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible"
                                        style="display: list-item;"><label class="gfield_label" for="input_1_8">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Detalhes do Requisito </font>
                                            </font><span class="gfield_required">
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">*</font>
                                                </font>
                                            </span>
                                        </label>
                                        <div class="ginput_container ginput_container_textarea"><textarea name="input_8"
                                                id="input_1_8" class="textarea large" onchange="gf_apply_rules(1,[8]);"
                                                onkeyup="clearTimeout(__gf_timeout_handle); __gf_timeout_handle = setTimeout(&quot;gf_apply_rules(1,[8])&quot;, 300);"
                                                placeholder="Detalhes de Requisito" aria-required="true"
                                                aria-invalid="false" rows="10" cols="50"></textarea></div>
                                    </li>
                                    <li id="field_1_9"
                                        class="gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible"
                                        style="display: none;"><label class="gfield_label" for="input_1_9">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Data de entrega </font>
                                            </font><span class="gfield_required">
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">*</font>
                                                </font>
                                            </span>
                                        </label>
                                        <div class="ginput_container ginput_container_date">
                                            <input name="input_9" id="input_1_9" type="text" value=""
                                                class="datepicker medium ymd_dash datepicker_no_icon hasDatepicker"
                                                placeholder="Data de Devolução" disabled="">
                                        </div>
                                        <input type="hidden" id="gforms_calendar_icon_input_1_9" class="gform_hidden"
                                            value="https://www.eazi.co.za/wp-content/plugins/gravityforms/images/calendar.png"
                                            disabled="">
                                    </li>
                                    <li id="field_1_10"
                                        class="gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible"
                                        style="display: none;"><label class="gfield_label" for="input_1_10">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Data de coleta </font>
                                            </font><span class="gfield_required">
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">*</font>
                                                </font>
                                            </span>
                                        </label>
                                        <div class="ginput_container ginput_container_date">
                                            <input name="input_10" id="input_1_10" type="text" value=""
                                                class="datepicker medium ymd_dash datepicker_no_icon hasDatepicker"
                                                placeholder="Data de Coleta" disabled="">
                                        </div>
                                        <input type="hidden" id="gforms_calendar_icon_input_1_10" class="gform_hidden"
                                            value="https://www.eazi.co.za/wp-content/plugins/gravityforms/images/calendar.png"
                                            disabled="">
                                    </li>
                                    <li id="field_1_11"
                                        class="gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible"
                                        style="display: none;"><label class="gfield_label" for="input_1_11">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Necessidades de mudança </font>
                                            </font><span class="gfield_required">
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">*</font>
                                                </font>
                                            </span>
                                        </label>
                                        <div class="ginput_container ginput_container_select"><select name="input_11"
                                                id="input_1_11" class="medium gfield_select" aria-required="true"
                                                aria-invalid="false">
                                                <option value="" selected="selected" class="gf_placeholder">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">Necessidades de mudança
                                                        </font>
                                                    </font>
                                                </option>
                                                <option value="People">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">Pessoas</font>
                                                    </font>
                                                </option>
                                                <option value="Material">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">Material</font>
                                                    </font>
                                                </option>
                                            </select></div>
                                    </li>
                                    <li id="field_1_12"
                                        class="gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible"
                                        style="display: none;"><label class="gfield_label" for="input_1_12">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Local de Trabalho </font>
                                            </font><span class="gfield_required">
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">*</font>
                                                </font>
                                            </span>
                                        </label>
                                        <div class="ginput_container ginput_container_select"><select name="input_12"
                                                id="input_1_12" class="medium gfield_select" aria-required="true"
                                                aria-invalid="false">
                                                <option value="" selected="selected" class="gf_placeholder">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">Local de Trabalho</font>
                                                    </font>
                                                </option>
                                                <option value="Mostly Outdoors (Engine Powered)">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">Principalmente ao ar
                                                            livre (motorizado)</font>
                                                    </font>
                                                </option>
                                                <option value="Mostly Indoor (Electric Powered)">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">Principalmente interno
                                                            (movido a eletricidade)</font>
                                                    </font>
                                                </option>
                                                <option value="Outdoor &amp; Indoor">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">Fora dentro</font>
                                                    </font>
                                                </option>
                                            </select></div>
                                    </li>
                                    <li id="field_1_13"
                                        class="gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible"
                                        style="display: none;"><label class="gfield_label" for="input_1_13">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Altura de Trabalho </font>
                                            </font><span class="gfield_required">
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">*</font>
                                                </font>
                                            </span>
                                        </label>
                                        <div class="ginput_container ginput_container_select"><select name="input_13"
                                                id="input_1_13" class="medium gfield_select" aria-required="true"
                                                aria-invalid="false">
                                                <option value="" selected="selected" class="gf_placeholder">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">Altura de Trabalho</font>
                                                    </font>
                                                </option>
                                                <option value="4.0—7.9 meters">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">4,0—7,9 metros</font>
                                                    </font>
                                                </option>
                                                <option value="7.9—9.5 meters">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">7,9—9,5 metros</font>
                                                    </font>
                                                </option>
                                                <option value="9.5—12.2 meters">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">9,5-12,2 metros</font>
                                                    </font>
                                                </option>
                                                <option value="12.2—15.2 meters">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">12,2-15,2 metros</font>
                                                    </font>
                                                </option>
                                                <option value="15.2—21.9 meters">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">15,2-21,9 metros</font>
                                                    </font>
                                                </option>
                                                <option value="21.9—27.4 meters">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">21,9-27,4 metros</font>
                                                    </font>
                                                </option>
                                                <option value="> 27.4 meters">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">&gt; 27,4 metros</font>
                                                    </font>
                                                </option>
                                            </select></div>
                                    </li>
                                    <li id="field_1_14"
                                        class="gfield gf_left_half gfield_contains_required field_sublabel_above field_description_below gfield_visibility_visible"
                                        style="display: none;"><label class="gfield_label" for="input_1_14">
                                            <font style="vertical-align: inherit;">
                                                <font style="vertical-align: inherit;">Peso de levantamento </font>
                                            </font><span class="gfield_required">
                                                <font style="vertical-align: inherit;">
                                                    <font style="vertical-align: inherit;">*</font>
                                                </font>
                                            </span>
                                        </label>
                                        <div class="ginput_container ginput_container_select"><select name="input_14"
                                                id="input_1_14" class="medium gfield_select" aria-required="true"
                                                aria-invalid="false">
                                                <option value="" selected="selected" class="gf_placeholder">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">Levantando peso</font>
                                                    </font>
                                                </option>
                                                <option value="100—500 kg">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">100—500 kg</font>
                                                    </font>
                                                </option>
                                                <option value="500—1500 kg">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">500—1500 kg</font>
                                                    </font>
                                                </option>
                                                <option value="1500—3000 kg">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">1500—3000 kg</font>
                                                    </font>
                                                </option>
                                                <option value="3000—5000 kg">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">3000—5000 kg</font>
                                                    </font>
                                                </option>
                                                <option value="5000—15000 kg">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">5000—15000 kg</font>
                                                    </font>
                                                </option>
                                                <option value="15000—30000 kg">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">15000—30000 kg</font>
                                                    </font>
                                                </option>
                                                <option value="> 30000 kg">
                                                    <font style="vertical-align: inherit;">
                                                        <font style="vertical-align: inherit;">&gt; 30000 kg</font>
                                                    </font>
                                                </option>
                                            </select></div>
                                    </li>
                                </ul>
                            </div>
                            <div class="gform_footer top_label">
                                <font style="vertical-align: inherit;">
                                    <font style="vertical-align: inherit;"><input type="submit"
                                            id="gform_submit_button_1" class="gform_button button" value="Enviar"
                                            onclick="if(window[&quot;gf_submitting_1&quot;]){return false;}  window[&quot;gf_submitting_1&quot;]=true;  "
                                            onkeypress="if( event.keyCode == 13 ){ if(window[&quot;gf_submitting_1&quot;]){return false;} window[&quot;gf_submitting_1&quot;]=true;  jQuery(&quot;#gform_1&quot;).trigger(&quot;submit&quot;,[true]); }">
                                    </font>
                                </font> <input type="hidden" name="gform_ajax"
                                    value="form_id=1&amp;title=&amp;description=&amp;tabindex=0">
                                <input type="hidden" class="gform_hidden" name="is_submit_1" value="1">
                                <input type="hidden" class="gform_hidden" name="gform_submit" value="1">

                                <input type="hidden" class="gform_hidden" name="gform_unique_id" value="">
                                <input type="hidden" class="gform_hidden" name="state_1"
                                    value="WyJbXSIsIjA0Mjg2MGQ4MGYwY2FkNjAyYzI4OGQwYTgwNWNmNzFmIl0=">
                                <input type="hidden" class="gform_hidden" name="gform_target_page_number_1"
                                    id="gform_target_page_number_1" value="0">
                                <input type="hidden" class="gform_hidden" name="gform_source_page_number_1"
                                    id="gform_source_page_number_1" value="1">
                                <input type="hidden" name="gform_field_values" value="">

                            </div>
                        </form>













                    </div>
                    <iframe style="display:none;width:0px;height:0px;" src="about:blank" name="gform_ajax_frame_1"
                        id="gform_ajax_frame_1">This iframe contains the logic required to handle Ajax powered Gravity
                        Forms.</iframe>
                    <script type="text/javascript">
                    jQuery(document).ready(function($) {
                        gformInitSpinner(1,
                            'https://www.eazi.co.za/wp-content/plugins/gravityforms/images/spinner.gif');
                        jQuery('#gform_ajax_frame_1').load(function() {
                            var contents = jQuery(this).contents().find('*').html();
                            var is_postback = contents.indexOf('GF_AJAX_POSTBACK') >= 0;
                            if (!is_postback) {
                                return;
                            }
                            var form_content = jQuery(this).contents().find('#gform_wrapper_1');
                            var is_confirmation = jQuery(this).contents().find(
                                '#gform_confirmation_wrapper_1').length > 0;
                            var is_redirect = contents.indexOf('gformRedirect(){') >= 0;
                            var is_form = form_content.length > 0 && !is_redirect && !is_confirmation;
                            if (is_form) {
                                jQuery('#gform_wrapper_1').html(form_content.html());
                                if (form_content.hasClass('gform_validation_error')) {
                                    jQuery('#gform_wrapper_1').addClass('gform_validation_error');
                                } else {
                                    jQuery('#gform_wrapper_1').removeClass('gform_validation_error');
                                }
                                setTimeout(function() {
                                    /* delay the scroll by 50 milliseconds to fix a bug in chrome */
                                    jQuery(document).scrollTop(jQuery('#gform_wrapper_1')
                                        .offset().top);
                                }, 50);
                                if (window['gformInitDatepicker']) {
                                    gformInitDatepicker();
                                }
                                if (window['gformInitPriceFields']) {
                                    gformInitPriceFields();
                                }
                                var current_page = jQuery('#gform_source_page_number_1').val();
                                gformInitSpinner(1,
                                    'https://www.eazi.co.za/wp-content/plugins/gravityforms/images/spinner.gif'
                                );
                                jQuery(document).trigger('gform_page_loaded', [1, current_page]);
                                window['gf_submitting_1'] = false;
                            } else if (!is_redirect) {
                                var confirmation_content = jQuery(this).contents().find(
                                    '.GF_AJAX_POSTBACK').html();
                                if (!confirmation_content) {
                                    confirmation_content = contents;
                                }
                                setTimeout(function() {
                                    jQuery('#gform_wrapper_1').replaceWith(
                                        confirmation_content);
                                    jQuery(document).scrollTop(jQuery('#gf_1').offset().top);
                                    jQuery(document).trigger('gform_confirmation_loaded', [1]);
                                    window['gf_submitting_1'] = false;
                                }, 50);
                            } else {
                                jQuery('#gform_1').append(contents);
                                if (window['gformRedirect']) {
                                    gformRedirect();
                                }
                            }
                            jQuery(document).trigger('gform_post_render', [1, current_page]);
                        });
                    });
                    </script>
                    <script type="text/javascript">
                    if (typeof gf_global == 'undefined') var gf_global = {
                        "gf_currency_config": {
                            "name": "South African Rand",
                            "symbol_left": "R",
                            "symbol_right": "",
                            "symbol_padding": "",
                            "thousand_separator": ",",
                            "decimal_separator": ".",
                            "decimals": 2
                        },
                        "base_url": "https:\/\/www.eazi.co.za\/wp-content\/plugins\/gravityforms",
                        "number_formats": [],
                        "spinnerUrl": "https:\/\/www.eazi.co.za\/wp-content\/plugins\/gravityforms\/images\/spinner.gif"
                    };
                    jQuery(document).bind('gform_post_render', function(event, formId, currentPage) {
                        if (formId == 1) {
                            gf_global["number_formats"][1] = {
                                "18": {
                                    "price": false,
                                    "value": false
                                },
                                "17": {
                                    "price": false,
                                    "value": false
                                },
                                "1": {
                                    "price": false,
                                    "value": false
                                },
                                "2": {
                                    "price": false,
                                    "value": false
                                },
                                "3": {
                                    "price": false,
                                    "value": false
                                },
                                "4": {
                                    "price": false,
                                    "value": false
                                },
                                "15": {
                                    "price": false,
                                    "value": false
                                },
                                "16": {
                                    "price": false,
                                    "value": false
                                },
                                "5": {
                                    "price": false,
                                    "value": false
                                },
                                "6": {
                                    "price": false,
                                    "value": false
                                },
                                "7": {
                                    "price": false,
                                    "value": false
                                },
                                "8": {
                                    "price": false,
                                    "value": false
                                },
                                "9": {
                                    "price": false,
                                    "value": false
                                },
                                "10": {
                                    "price": false,
                                    "value": false
                                },
                                "11": {
                                    "price": false,
                                    "value": false
                                },
                                "12": {
                                    "price": false,
                                    "value": false
                                },
                                "13": {
                                    "price": false,
                                    "value": false
                                },
                                "14": {
                                    "price": false,
                                    "value": false
                                }
                            };
                            if (window['jQuery']) {
                                if (!window['gf_form_conditional_logic']) window['gf_form_conditional_logic'] =
                                    new Array();
                                window['gf_form_conditional_logic'][1] = {
                                    logic: {
                                        16: {
                                            "field": {
                                                "actionType": "show",
                                                "logicType": "any",
                                                "rules": [{
                                                    "fieldId": "15.1",
                                                    "operator": "is",
                                                    "value": "South Africa"
                                                }, {
                                                    "fieldId": "15.2",
                                                    "operator": "is",
                                                    "value": "Gauteng - Midrand"
                                                }]
                                            },
                                            "nextButton": null,
                                            "section": null
                                        },
                                        5: {
                                            "field": {
                                                "actionType": "show",
                                                "logicType": "all",
                                                "rules": [{
                                                    "fieldId": 5,
                                                    "operator": "is",
                                                    "value": "__adv_cond_logic"
                                                }, {
                                                    "fieldId": 17,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 17,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 18,
                                                    "operator": "isnot",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 17,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 18,
                                                    "operator": "isnot",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 17,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 18,
                                                    "operator": "isnot",
                                                    "value": "__return_true"
                                                }]
                                            },
                                            "nextButton": null,
                                            "section": null
                                        },
                                        6: {
                                            "field": {
                                                "actionType": "show",
                                                "logicType": "all",
                                                "rules": [{
                                                    "fieldId": 6,
                                                    "operator": "is",
                                                    "value": "__adv_cond_logic"
                                                }, {
                                                    "fieldId": 17,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }]
                                            },
                                            "nextButton": null,
                                            "section": null
                                        },
                                        7: {
                                            "field": {
                                                "actionType": "show",
                                                "logicType": "all",
                                                "rules": [{
                                                    "fieldId": 7,
                                                    "operator": "is",
                                                    "value": "__adv_cond_logic"
                                                }, {
                                                    "fieldId": 17,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 6,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 17,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 6,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 17,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 18,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 17,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 18,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }]
                                            },
                                            "nextButton": null,
                                            "section": null
                                        },
                                        8: {
                                            "field": {
                                                "actionType": "show",
                                                "logicType": "all",
                                                "rules": [{
                                                    "fieldId": 8,
                                                    "operator": "is",
                                                    "value": "__adv_cond_logic"
                                                }, {
                                                    "fieldId": 17,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 6,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 17,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 6,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 17,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 18,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 17,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }, {
                                                    "fieldId": 18,
                                                    "operator": "is",
                                                    "value": "__return_true"
                                                }]
                                            },
                                            "nextButton": null,
                                            "section": null
                                        },
                                        9: {
                                            "field": {
                                                "actionType": "show",
                                                "logicType": "all",
                                                "rules": [{
                                                    "fieldId": "17",
                                                    "operator": "is",
                                                    "value": "Rental"
                                                }]
                                            },
                                            "nextButton": null,
                                            "section": null
                                        },
                                        10: {
                                            "field": {
                                                "actionType": "show",
                                                "logicType": "all",
                                                "rules": [{
                                                    "fieldId": "17",
                                                    "operator": "is",
                                                    "value": "Rental"
                                                }]
                                            },
                                            "nextButton": null,
                                            "section": null
                                        },
                                        11: {
                                            "field": {
                                                "actionType": "show",
                                                "logicType": "all",
                                                "rules": [{
                                                    "fieldId": "6",
                                                    "operator": "is",
                                                    "value": "Help me choose what I need\u2026"
                                                }]
                                            },
                                            "nextButton": null,
                                            "section": null
                                        },
                                        12: {
                                            "field": {
                                                "actionType": "show",
                                                "logicType": "all",
                                                "rules": [{
                                                    "fieldId": "6",
                                                    "operator": "is",
                                                    "value": "Help me choose what I need\u2026"
                                                }]
                                            },
                                            "nextButton": null,
                                            "section": null
                                        },
                                        13: {
                                            "field": {
                                                "actionType": "show",
                                                "logicType": "all",
                                                "rules": [{
                                                    "fieldId": "6",
                                                    "operator": "is",
                                                    "value": "Help me choose what I need\u2026"
                                                }]
                                            },
                                            "nextButton": null,
                                            "section": null
                                        },
                                        14: {
                                            "field": {
                                                "actionType": "show",
                                                "logicType": "all",
                                                "rules": [{
                                                    "fieldId": "6",
                                                    "operator": "is",
                                                    "value": "Help me choose what I need\u2026"
                                                }]
                                            },
                                            "nextButton": null,
                                            "section": null
                                        }
                                    },
                                    dependents: {
                                        16: [16],
                                        5: [5],
                                        6: [6],
                                        7: [7],
                                        8: [8],
                                        9: [9],
                                        10: [10],
                                        11: [11],
                                        12: [12],
                                        13: [13],
                                        14: [14]
                                    },
                                    animation: 0,
                                    defaults: {
                                        "6": "Equipment Selector"
                                    },
                                    fields: {
                                        "18": [5, 7, 8],
                                        "17": [5, 6, 7, 8, 9, 10],
                                        "1": [],
                                        "2": [],
                                        "3": [],
                                        "4": [],
                                        "15": [16],
                                        "16": [],
                                        "5": [5],
                                        "6": [6, 7, 8, 11, 12, 13, 14],
                                        "7": [7],
                                        "8": [8],
                                        "9": [],
                                        "10": [],
                                        "11": [],
                                        "12": [],
                                        "13": [],
                                        "14": []
                                    }
                                };
                                if (!window['gf_number_format']) window['gf_number_format'] = 'decimal_dot';
                                jQuery(document).ready(function() {
                                    gf_apply_rules(1, [16, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14], true);
                                    jQuery('#gform_wrapper_1').show();
                                    jQuery(document).trigger('gform_post_conditional_logic', [1, null,
                                        true
                                    ]);
                                });
                            }
                            if (typeof Placeholders != 'undefined') {
                                Placeholders.enable();
                            }
                            jQuery('#input_1_3').mask('(999) 999-9999').bind('keypress', function(e) {
                                if (e.which == 13) {
                                    jQuery(this).blur();
                                }
                            });;
                            new GFChainedSelects(1, 15, 0, "horizontal");
                            (function($) {
                                gf_datepicker_limit_past()
                            })(jQuery);
                            new GWAdvCondLogic({
                                "formId": 1,
                                "logic": {
                                    "5": {
                                        "actionType": "show",
                                        "logicType": null,
                                        "groups": [{
                                            "actionType": "show",
                                            "logicType": "all",
                                            "rules": [{
                                                "fieldId": 17,
                                                "operator": "is",
                                                "value": "Rental"
                                            }]
                                        }, {
                                            "actionType": "show",
                                            "logicType": "all",
                                            "rules": [{
                                                "fieldId": 17,
                                                "operator": "is",
                                                "value": "Buy"
                                            }, {
                                                "fieldId": 18,
                                                "operator": "isnot"
                                            }]
                                        }, {
                                            "actionType": "show",
                                            "logicType": "all",
                                            "rules": [{
                                                "fieldId": 17,
                                                "operator": "is",
                                                "value": "Service"
                                            }, {
                                                "fieldId": 18,
                                                "operator": "isnot"
                                            }]
                                        }, {
                                            "actionType": "show",
                                            "logicType": "all",
                                            "rules": [{
                                                "fieldId": 17,
                                                "operator": "is",
                                                "value": "Training"
                                            }, {
                                                "fieldId": 18,
                                                "operator": "isnot"
                                            }]
                                        }]
                                    },
                                    "6": {
                                        "actionType": "show",
                                        "logicType": null,
                                        "groups": [{
                                            "actionType": "show",
                                            "logicType": "all",
                                            "rules": [{
                                                "fieldId": 17,
                                                "operator": "is",
                                                "value": "Rental"
                                            }]
                                        }]
                                    },
                                    "7": {
                                        "actionType": "show",
                                        "logicType": null,
                                        "groups": [{
                                            "actionType": "show",
                                            "logicType": "all",
                                            "rules": [{
                                                "fieldId": 17,
                                                "operator": "is",
                                                "value": "Rental"
                                            }, {
                                                "fieldId": 6,
                                                "operator": "is",
                                                "value": "Equipment Selector"
                                            }]
                                        }, {
                                            "actionType": "show",
                                            "logicType": "all",
                                            "rules": [{
                                                "fieldId": 17,
                                                "operator": "is",
                                                "value": "Rental"
                                            }, {
                                                "fieldId": 6,
                                                "operator": "is",
                                                "value": "I know what equipment I need\u2026"
                                            }]
                                        }, {
                                            "actionType": "show",
                                            "logicType": "all",
                                            "rules": [{
                                                "fieldId": 17,
                                                "operator": "is",
                                                "value": "Buy"
                                            }, {
                                                "fieldId": 18,
                                                "operator": "is"
                                            }]
                                        }, {
                                            "actionType": "show",
                                            "logicType": "all",
                                            "rules": [{
                                                "fieldId": 17,
                                                "operator": "is",
                                                "value": "Service"
                                            }, {
                                                "fieldId": 18,
                                                "operator": "is"
                                            }]
                                        }]
                                    },
                                    "8": {
                                        "actionType": "show",
                                        "logicType": null,
                                        "groups": [{
                                            "actionType": "show",
                                            "logicType": "all",
                                            "rules": [{
                                                "fieldId": 17,
                                                "operator": "is",
                                                "value": "Rental"
                                            }, {
                                                "fieldId": 6,
                                                "operator": "is",
                                                "value": "Equipment Selector"
                                            }]
                                        }, {
                                            "actionType": "show",
                                            "logicType": "all",
                                            "rules": [{
                                                "fieldId": 17,
                                                "operator": "is",
                                                "value": "Rental"
                                            }, {
                                                "fieldId": 6,
                                                "operator": "is",
                                                "value": "I know what equipment I need\u2026"
                                            }]
                                        }, {
                                            "actionType": "show",
                                            "logicType": "all",
                                            "rules": [{
                                                "fieldId": 17,
                                                "operator": "is",
                                                "value": "Buy"
                                            }, {
                                                "fieldId": 18,
                                                "operator": "is"
                                            }]
                                        }, {
                                            "actionType": "show",
                                            "logicType": "all",
                                            "rules": [{
                                                "fieldId": 17,
                                                "operator": "is",
                                                "value": "Service"
                                            }, {
                                                "fieldId": 18,
                                                "operator": "is"
                                            }]
                                        }]
                                    }
                                }
                            });
                        }
                    });
                    jQuery(document).bind('gform_post_conditional_logic', function(event, formId, fields, isInit) {});
                    </script>
                    <script type="text/javascript">
                    jQuery(document).ready(function() {
                        jQuery(document).trigger('gform_post_render', [1, 1])
                    });
                    </script>
                </div> <!-- .et_pb_code_inner -->
            </div> <!-- .et_pb_code -->
        </div> <!-- .et_pb_column -->


    </div> <!-- .et_pb_row -->


</div>